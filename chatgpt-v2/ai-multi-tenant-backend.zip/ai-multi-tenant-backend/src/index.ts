import 'dotenv/config';
import { createApp } from './app';
import { startCronJobs } from './system/cron.service';

const PORT = parseInt(process.env.PORT || '8080', 10);
const app = createApp();

app.listen(PORT, () => {
  console.log(`Backend listening on port ${PORT}`);
});

startCronJobs();
