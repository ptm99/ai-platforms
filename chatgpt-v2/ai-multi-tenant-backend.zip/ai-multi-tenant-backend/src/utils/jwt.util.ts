import jwt, { SignOptions } from 'jsonwebtoken';

export type UserRole = 'user' | 'admin' | 'superadmin';

export interface AccessTokenPayload {
  sub: string;
  role: UserRole;
  email?: string;
}

export function signAccessToken(payload: AccessTokenPayload): string {
  const secret = process.env.JWT_ACCESS_SECRET;
  if (!secret) throw new Error('JWT_ACCESS_SECRET not set');
  const expiresIn = process.env.JWT_ACCESS_EXPIRES_IN || '15m';
  const options: SignOptions = { expiresIn };
  return jwt.sign(payload, secret, options);
}

export function signRefreshToken(payload: { sub: string }): string {
  const secret = process.env.JWT_REFRESH_SECRET;
  if (!secret) throw new Error('JWT_REFRESH_SECRET not set');
  const expiresIn = process.env.JWT_REFRESH_EXPIRES_IN || '30d';
  const options: SignOptions = { expiresIn };
  return jwt.sign(payload, secret, options);
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  const secret = process.env.JWT_ACCESS_SECRET;
  if (!secret) throw new Error('JWT_ACCESS_SECRET not set');
  return jwt.verify(token, secret) as AccessTokenPayload;
}

export function verifyRefreshToken(token: string): { sub: string } {
  const secret = process.env.JWT_REFRESH_SECRET;
  if (!secret) throw new Error('JWT_REFRESH_SECRET not set');
  return jwt.verify(token, secret) as { sub: string };
}
