import path from 'node:path';
import url from 'node:url';
import { ProviderAdapter } from './adapter.types.js';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));

/**
 * adapter_file is stored like "openai.adapter" (no extension).
 * At runtime we execute compiled JS from dist/, so we always import *.js.
 */
export async function loadAdapter(adapterFile: string): Promise<ProviderAdapter> {
  const jsPath = path.join(__dirname, '..', '..', 'providers', 'adapters', `${adapterFile}.js`);
  const mod = await import(url.pathToFileURL(jsPath).toString());
  if (!mod.default) throw new Error(`Adapter ${adapterFile} does not export default`);
  return mod.default as ProviderAdapter;
}
