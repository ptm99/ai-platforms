// tests/projectSharing.service.test.ts

import { jest } from '@jest/globals';

jest.unstable_mockModule('../src/db/pool', () => {
  const query = jest.fn();
  const connect = jest.fn().mockResolvedValue({
    query,
    release: jest.fn()
  });
  return {
    pool: { query, connect }
  };
});

const { pool } = await import('../src/db/pool');
const {
  updateProjectVisibility,
  leaveProject
} = await import('../src/modules/projects/project.service');

describe('Project sharing service validations', () => {
  beforeEach(() => {
    (pool.query as jest.Mock).mockReset();
    (pool.connect as jest.Mock).mockReset();
  });

  test('updateProjectVisibility throws when project not found', async () => {
    (pool.connect as jest.Mock).mockResolvedValue({
      query: jest.fn()
        .mockResolvedValueOnce({ rows: [] }), // getProjectById -> not found
      release: jest.fn()
    });

    await expect(updateProjectVisibility('proj-1', 'private')).rejects.toThrow(
      'Project not found'
    );
  });

  test('updateProjectVisibility to shared with no members throws', async () => {
    const query = jest.fn()
      // getProjectById
      .mockResolvedValueOnce({ rows: [{ id: 'proj-1', visibility: 'private' }] })
      // countProjectMembers
      .mockResolvedValueOnce({ rows: [{ count: 0 }] });

    (pool.connect as jest.Mock).mockResolvedValue({
      query,
      release: jest.fn()
    });

    await expect(updateProjectVisibility('proj-1', 'shared')).rejects.toThrow(
      'Cannot set visibility to shared without collaborators'
    );
  });

  test('leaveProject forbids owner leaving own project', async () => {
    (pool.query as jest.Mock).mockResolvedValueOnce({
      rows: [{ id: 'proj-1', owner_id: 10 }]
    });

    await expect(leaveProject('proj-1', '10')).rejects.toThrow(
      'Owner cannot leave their own project'
    );
  });
});
