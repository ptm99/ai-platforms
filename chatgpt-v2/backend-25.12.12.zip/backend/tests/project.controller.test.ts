// tests/project.controller.test.ts

import request from 'supertest';
import { jest } from '@jest/globals';

/**
 * Mock auth middleware to inject a stable user identity.
 * We do NOT test JWT here; we test controller behavior + validation.
 */
jest.unstable_mockModule('../src/middleware/auth.middleware', () => {
  return {
    authRequired: (req: any, _res: any, next: any) => {
      req.user = { id: '100', role: 'superadmin' };
      next();
    },
    requireRole: (_minRole: any) => (_req: any, _res: any, next: any) => next()
  };
});

/**
 * Mock project.service to avoid DB access and to validate controller logic.
 */
jest.unstable_mockModule('../src/modules/projects/project.service', () => {
  const members = [
    {
      user_id: '100',
      email: 'owner@example.com',
      display_name: 'Owner',
      role: 'owner',
      permission: null,
      added_at: new Date().toISOString()
    }
  ];

  return {
    createProject: jest.fn(async () => ({
      id: 'p1',
      owner_id: '100',
      title: 'Demo',
      visibility: 'private',
      provider_id: 'prov1',
      model_id: 'm1',
      provider_key_id: 'k1',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })),
    listUserProjects: jest.fn(async () => []),
    getProjectById: jest.fn(async (id: string) => {
      if (id !== 'p1') return null;
      return {
        id: 'p1',
        owner_id: '100',
        title: 'Demo',
        visibility: 'private',
        provider_id: 'prov1',
        model_id: 'm1',
        provider_key_id: 'k1',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
    }),
    userCanReadProject: jest.fn(async () => true),
    userCanEditProject: jest.fn(async () => true),
    userIsProjectOwner: jest.fn(async (userId: string, projectId: string) => userId === '100' && projectId === 'p1'),
    listProjectMembers: jest.fn(async () => members),
    addOrUpdateProjectMember: jest.fn(async () => {}),
    removeProjectMember: jest.fn(async () => {}),
    updateProjectVisibility: jest.fn(async (_projectId: string, visibility: string) => ({
      id: 'p1',
      owner_id: '100',
      title: 'Demo',
      visibility,
      provider_id: 'prov1',
      model_id: 'm1',
      provider_key_id: 'k1',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })),
    leaveProject: jest.fn(async () => {}),
    cloneProject: jest.fn(async () => ({
      id: 'p2',
      owner_id: '100',
      title: 'Demo (Copy)',
      visibility: 'private',
      provider_id: 'prov1',
      model_id: 'm1',
      provider_key_id: 'k1',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    })),
    findUserByEmail: jest.fn(async (email: string) => {
      if (email.toLowerCase() === 'user2@example.com') return { id: '200', email: 'user2@example.com', display_name: 'User2' };
      return null;
    }),
    countProjectMembers: jest.fn(async () => 0)
  };
});

const { createApp } = await import('../src/app');

describe('Project controller (sharing validations)', () => {
  const app = createApp();

  test('POST /projects validates missing fields', async () => {
    const res = await request(app).post('/projects').send({ title: 'x' });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/required/i);
  });

  test('PATCH /projects/:id/visibility rejects invalid value', async () => {
    const res = await request(app).patch('/projects/p1/visibility').send({ visibility: 'bad' });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Invalid visibility/i);
  });

  test('POST /projects/:id/members rejects missing email', async () => {
    const res = await request(app).post('/projects/p1/members').send({ permission: 'read' });
    expect(res.status).toBe(400);
  });

  test('POST /projects/:id/clone returns new project', async () => {
    const res = await request(app).post('/projects/p1/clone').send({});
    expect(res.status).toBe(201);
    expect(res.body.id).toBe('p2');
  });
});
