import { Request, Response, NextFunction } from 'express';
import { AuthUser } from './auth.middleware';

type Role = AuthUser['role'];

const order: Role[] = ['user', 'admin', 'superadmin'];

export function requireRole(minRole: Role) {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = req.user;
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    const userIdx = order.indexOf(user.role);
    const minIdx = order.indexOf(minRole);
    if (userIdx < 0 || userIdx < minIdx) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    next();
  };
}
