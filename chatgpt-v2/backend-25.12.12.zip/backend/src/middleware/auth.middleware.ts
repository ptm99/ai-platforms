// src/middleware/auth.middleware.ts

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

export type UserRole = 'user' | 'admin' | 'superadmin';

export interface AuthUser {
  id: string;
  role: UserRole;
  email?: string;
}

interface AuthedRequest extends Request {
  user?: AuthUser;
}

const ROLE_RANK: Record<UserRole, number> = {
  user: 1,
  admin: 2,
  superadmin: 3
};

export function authRequired(req: Request, res: Response, next: NextFunction) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice('Bearer '.length) : null;

  if (!token) return res.status(401).json({ error: 'Missing Authorization token' });

  try {
    const secret = process.env.JWT_ACCESS_SECRET;
    if (!secret) return res.status(500).json({ error: 'JWT_ACCESS_SECRET not set' });

    const payload = jwt.verify(token, secret) as any;
    (req as AuthedRequest).user = {
      id: String(payload.sub),
      role: payload.role as UserRole,
      email: payload.email
    };
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

export function requireRole(minRole: UserRole) {
  return (req: Request, res: Response, next: NextFunction) => {
    const u = (req as AuthedRequest).user;
    if (!u) return res.status(401).json({ error: 'Unauthorized' });

    if (ROLE_RANK[u.role] < ROLE_RANK[minRole]) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    next();
  };
}
