// src/app.ts

import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import bodyParser from 'body-parser';

import { authRouter } from './modules/auth/auth.controller';
import { projectRouter } from './modules/projects/project.controller';
import { adminRouter } from './modules/admin/admin.router';

export function createApp() {
  const app = express();

  app.use(helmet());
  app.use(cors({ origin: true, credentials: true }));
  app.use(bodyParser.json({ limit: '2mb' }));

  app.get('/health', (_req, res) => res.json({ ok: true }));

  app.use('/auth', authRouter);
  app.use('/projects', projectRouter);
  app.use('/admin', adminRouter);

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  app.use((err: any, _req: any, res: any, _next: any) => {
    console.error('[express error]', err);
    res.status(500).json({ error: 'Internal server error' });
  });

  return app;
}
