// backend/src/system/healthCheck.service.ts
import fs from 'fs';
import path from 'path';
import { pool } from '../db/pool';
import { providerAdapters } from '../modules/providers/adapters';
import { config } from '../config';

export interface HealthStatus {
  status: 'ok' | 'warning' | 'error';
  checks: Record<string, any>;
}

//
// 1. Check required filesystem paths exist
//
function checkRequiredPaths(): Record<string, any> {
  const root = path.resolve(__dirname, '../../');
  const required = [
    'src',
    'src/modules',
    'src/modules/providers',
    'src/modules/projects',
    'src/modules/messages',
    'src/utils'
  ];

  const results: Record<string, any> = {};
  required.forEach((p) => {
    const full = path.join(root, p);
    results[p] = fs.existsSync(full)
      ? { status: 'ok' }
      : { status: 'error', message: 'Missing directory' };
  });

  return results;
}

//
// 2. Check environment variables
//
function checkEnv(): Record<string, any> {
  const required = [
    'DATABASE_URL',
    'JWT_SECRET',
    'API_KEY_ENCRYPTION_SECRET'
  ];

  const results: Record<string, any> = {};

  for (const v of required) {
    results[v] = process.env[v]
      ? { status: 'ok' }
      : { status: 'error', message: 'Missing environment variable' };
  }

  return results;
}

//
// 3. Check database connectivity and important tables
//
async function checkDatabase(): Promise<Record<string, any>> {
  const result: Record<string, any> = {};

  try {
    await pool.query('SELECT 1');
    result.connection = { status: 'ok' };
  } catch (err: any) {
    result.connection = { status: 'error', message: err.message };
    return result; // cannot check tables if DB itself fails
  }

  const requiredTables = [
    'users',
    'ai_providers',
    'ai_provider_keys',
    'projects',
    'project_members',
    'messages',
    'usage_logs'
  ];

  for (const table of requiredTables) {
    try {
      await pool.query(`SELECT 1 FROM ${table} LIMIT 1`);
      result[`table:${table}`] = { status: 'ok' };
    } catch (err: any) {
      result[`table:${table}`] = { status: 'error', message: 'Table missing or unreadable' };
    }
  }

  return result;
}

//
// 4. Provider configuration check
//
async function checkProviders(): Promise<Record<string, any>> {
  const results: Record<string, any> = {};

  try {
    const res = await pool.query(`SELECT code, id FROM ai_providers ORDER BY code ASC`);
    const providers = res.rows;

    if (!providers.length) {
      results.providers = { status: 'warning', message: 'No providers configured in DB' };
      return results;
    }

    results.providers = { status: 'ok', count: providers.length };

    // Check adapter availability
    providers.forEach((p: any) => {
      if (providerAdapters[p.code]) {
        results[`adapter:${p.code}`] = { status: 'ok' };
      } else {
        results[`adapter:${p.code}`] = {
          status: 'warning',
          message: 'No adapter implemented for this provider'
        };
      }
    });
  } catch (err: any) {
    results.providers = { status: 'error', message: err.message };
  }

  return results;
}

//
// 5. Key availability & exhaustion
//
async function checkProviderKeys(): Promise<Record<string, any>> {
  const results: Record<string, any> = {};

  try {
    const res = await pool.query(`
      SELECT p.code, k.status, k.daily_usage, k.daily_limit
      FROM ai_provider_keys k
      JOIN ai_providers p ON p.id = k.provider_id
      ORDER BY p.code ASC, k.created_at ASC
    `);

    if (!res.rows.length) {
      results.keys = { status: 'warning', message: 'No API keys configured' };
      return results;
    }

    const grouped: Record<string, any> = {};

    res.rows.forEach((row: any) => {
      if (!grouped[row.code]) grouped[row.code] = [];

      grouped[row.code].push({
        status: row.status,
        used: row.daily_usage,
        limit: row.daily_limit
      });
    });

    Object.keys(grouped).forEach((code) => {
      const keys = grouped[code];
      const allExhausted = keys.every((k) => k.status !== 'active' || k.used >= k.limit);

      results[`provider_keys:${code}`] = allExhausted
        ? {
            status: 'warning',
            message: 'All keys are exhausted or disabled',
            keys
          }
        : {
            status: 'ok',
            keys
          };
    });

    return results;
  } catch (err: any) {
    results.keys = { status: 'error', message: err.message };
    return results;
  }
}

//
// 6. Combine all checks
//
export async function runSystemHealthCheck(): Promise<HealthStatus> {
  const fileCheck = checkRequiredPaths();
  const envCheck = checkEnv();
  const dbCheck = await checkDatabase();
  const providerCheck = await checkProviders();
  const keyCheck = await checkProviderKeys();

  const allChecks = {
    files: fileCheck,
    env: envCheck,
    database: dbCheck,
    providers: providerCheck,
    keys: keyCheck
  };

  // Determine worst status
  const flattened = Object.values(allChecks).flatMap((section: any) =>
    Object.values(section)
  );

  const hasError = flattened.some((c: any) => c.status === 'error');
  const hasWarning = flattened.some((c: any) => c.status === 'warning');

  const status: HealthStatus['status'] =
    hasError ? 'error' : hasWarning ? 'warning' : 'ok';

  return {
    status,
    checks: allChecks
  };
}
