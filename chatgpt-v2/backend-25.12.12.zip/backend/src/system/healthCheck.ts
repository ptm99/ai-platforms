// src/system/healthCheck.ts

import { pool } from '../db/pool';

/**
 * Run a few basic checks to ensure DB and core tables are available.
 * Throw an error if something critical is missing.
 */
export async function verifySystemIntegrity(): Promise<void> {
  try {
    // Basic DB connectivity
    await pool.query('SELECT 1');

    // Check that a few core tables exist
    const tablesToCheck = [
      'users',
      'ai_providers',
      'ai_provider_models',
      'ai_provider_keys',
      'projects',
      'messages'
    ];

    for (const table of tablesToCheck) {
      const res = await pool.query(
        `
        SELECT to_regclass($1) AS exists
        `,
        [table]
      );
      if (!res.rows[0].exists) {
        throw new Error(`Required table missing: ${table}`);
      }
    }

    // Optionally, check there is at least one provider
    const providerCount = await pool.query('SELECT COUNT(*) FROM ai_providers');
    if (Number(providerCount.rows[0].count) === 0) {
      console.warn('[HealthCheck] No providers configured yet in ai_providers.');
    }

    console.log('[HealthCheck] System integrity OK.');
  } catch (err: any) {
    console.error('[HealthCheck] FAILED:', err.message);
    throw err;
  }
}
