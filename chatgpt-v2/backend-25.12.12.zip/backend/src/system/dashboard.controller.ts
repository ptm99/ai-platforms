import { Router, Request, Response } from 'express';
import { authRequired } from '../middleware/auth.middleware';
import { requireRole } from '../middleware/role.middleware';
import { pool } from '../db/pool';

export const dashboardRouter = Router();

dashboardRouter.use(authRequired);
dashboardRouter.use(requireRole('admin'));

// GET /system/overview
dashboardRouter.get('/overview', async (_req: Request, res: Response) => {
  try {
    const [users, projects, providers, messages] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM users'),
      pool.query('SELECT COUNT(*) FROM projects'),
      pool.query('SELECT COUNT(*) FROM ai_providers'),
      pool.query('SELECT COUNT(*) FROM messages')
    ]);

    res.json({
      users: Number(users.rows[0].count),
      projects: Number(projects.rows[0].count),
      providers: Number(providers.rows[0].count),
      messages: Number(messages.rows[0].count)
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});
