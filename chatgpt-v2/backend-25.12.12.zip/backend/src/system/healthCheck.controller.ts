// backend/src/system/healthCheck.controller.ts
import { Router, Request, Response } from 'express';
import { runSystemHealthCheck } from './healthCheck.service';

export const systemHealthRouter = Router();

// GET /system/health
systemHealthRouter.get('/health', async (_req: Request, res: Response) => {
  try {
    const report = await runSystemHealthCheck();
    const statusCode = report.status === 'ok' ? 200 : report.status === 'warning' ? 206 : 500;
    res.status(statusCode).json(report);
  } catch (err: any) {
    res.status(500).json({ status: 'error', message: err.message });
  }
});
