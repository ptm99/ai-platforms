// backend/src/system/cron.service.ts

import cron from 'node-cron';
import { resetDailyUsageForAllKeys } from '../modules/providers/keySelector.service';
import { syncProviderModelsFromAPIs } from './modelDiscovery.service';

export function startCronJobs() {
  console.log('[Cron] Initializing cron jobs...');

  // 1. Midnight: reset key usage
  cron.schedule('0 0 * * *', async () => {
    console.log('[Cron] Resetting daily usage for all keys...');
    await resetDailyUsageForAllKeys();
    console.log('[Cron] Daily usage reset complete.');
  });

  // 2. 03:00 daily: sync models from providers
  cron.schedule('0 3 * * *', async () => {
    console.log('[Cron] Syncing provider models from APIs...');
    await syncProviderModelsFromAPIs();
  });
}
