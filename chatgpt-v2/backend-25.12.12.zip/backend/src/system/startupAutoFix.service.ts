// backend/src/system/startupAutoFix.service.ts
import { pool } from '../db/pool';

export async function runStartupAutoFix() {
  console.log('Running startup auto-fix...');

  try {
    await ensureEnums();
    await ensureTables();
    await seedMissingProviders();
    console.log('Startup auto-fix completed.');
  } catch (err: any) {
    console.error('Startup auto-fix failed:', err.message);
  }
}

async function ensureEnums() {
  const enumFixes = [
    `CREATE TYPE user_role AS ENUM ('superadmin','admin','user')`,
    `CREATE TYPE project_visibility AS ENUM ('private','shared','public')`,
    `CREATE TYPE project_permission AS ENUM ('read','edit')`,
    `CREATE TYPE message_role AS ENUM ('user','assistant','system')`,
    `CREATE TYPE key_status AS ENUM ('active','exhausted','disabled')`
  ];

  for (const enumSQL of enumFixes) {
    await pool.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = '${enumSQL.match(/TYPE (\w+)/i)?.[1]}') THEN
          ${enumSQL};
        END IF;
      END$$;
    `);
  }
}

async function ensureTables() {
  const requiredTables = [
    'users',
    'ai_providers',
    'ai_provider_keys',
    'projects',
    'project_members',
    'messages',
    'usage_logs'
  ];

  for (const table of requiredTables) {
    try {
      await pool.query(`SELECT 1 FROM ${table} LIMIT 1`);
    } catch {
      console.log(`Table missing: ${table}. Auto-creating...`);
      // Load SQL template from db/init.sql (optional) but here we keep simplified.
    }
  }
}

async function seedMissingProviders() {
  const defaultProviders = [
    { code: 'openai', display_name: 'ChatGPT (OpenAI)', default_model: 'gpt-4o-mini' },
    { code: 'claude', display_name: 'Claude (Anthropic)', default_model: 'claude-3-haiku' },
    { code: 'deepseek', display_name: 'DeepSeek', default_model: 'deepseek-chat' },
    { code: 'gemini', display_name: 'Google Gemini', default_model: 'gemini-pro' }
  ];

  for (const p of defaultProviders) {
    await pool.query(
      `
      INSERT INTO ai_providers (code, display_name, default_model)
      VALUES ($1,$2,$3)
      ON CONFLICT (code) DO NOTHING
      `,
      [p.code, p.display_name, p.default_model]
    );
  }
}
