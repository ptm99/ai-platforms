// src/modules/messages/message.controller.ts

import { Router, Request, Response } from 'express';
import { authRequired } from '../../middleware/auth.middleware';
import { userCanReadProject } from '../projects/project.service';
import {
  listProjectMessages,
  sendMessageToProject,
  sendMessageToProjectStream
} from './message.service';

export const messageRouter = Router();

interface AuthenticatedRequest extends Request {
  user: { id: string; role: string };
}

messageRouter.use(authRequired);

// GET /messages/:projectId
messageRouter.get('/:projectId', async (req: Request, res: Response) => {
  const userId = (req as AuthenticatedRequest).user.id;
  const projectId = req.params.projectId;

  const canRead = await userCanReadProject(userId, projectId);
  if (!canRead) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  const messages = await listProjectMessages(projectId);
  res.json(messages);
});

// POST /messages/:projectId   (non-streaming)
messageRouter.post('/:projectId', async (req: Request, res: Response) => {
  try {
    const userId = (req as AuthenticatedRequest).user.id;
    const projectId = req.params.projectId;
    const { content } = req.body;

    if (!content || typeof content !== 'string') {
      return res.status(400).json({ error: 'content is required' });
    }

    const result = await sendMessageToProject({
      projectId,
      userId,
      userContent: content
    });

    res.json(result);
  } catch (err: any) {
    res
      .status(400)
      .json({ error: err.message || 'Failed to send message to project' });
  }
});

// GET /messages/stream/:projectId?content=...
messageRouter.get(
  '/stream/:projectId',
  async (req: Request, res: Response) => {
    try {
      const userId = (req as AuthenticatedRequest).user.id;
      const projectId = req.params.projectId;
      const content = req.query.content as string | undefined;

      if (!content) {
        return res.status(400).json({ error: 'content query param is required' });
      }

      // SSE headers
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');

      const stream = await sendMessageToProjectStream({
        projectId,
        userId,
        userContent: content
      });

      const sendEvent = (event: string, data: any) => {
        res.write(`event: ${event}\n`);
        res.write(`data: ${JSON.stringify(data)}\n\n`);
      };

      (async () => {
        try {
          for await (const chunk of stream) {
            if (chunk.type === 'delta') {
              sendEvent('delta', { content: chunk.content });
            } else if (chunk.type === 'done') {
              sendEvent('done', { usage: chunk.usage });
            } else if (chunk.type === 'error') {
              sendEvent('error', { message: chunk.content ?? 'Unknown error' });
            }
          }
          res.end();
        } catch (err: any) {
          sendEvent('error', { message: err.message || 'Streaming error' });
          res.end();
        }
      })();
    } catch (err: any) {
      res
        .status(400)
        .json({ error: err.message || 'Failed to initialize streaming' });
    }
  }
);
