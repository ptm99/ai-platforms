// src/modules/messages/message.service.ts

import { pool } from '../../db/pool';
import { getProjectById } from '../projects/project.service';
import { getProviderById, getModelById } from '../providers/provider.service';
import { incrementKeyUsage } from '../providers/keySelector.service';
import { getAdapter } from '../providers/adapters/adapterLoader';
import {
  ChatMessage,
  ChatStreamChunk
} from '../providers/provider.types';

export async function listProjectMessages(projectId: string) {
  const res = await pool.query(
    `
    SELECT id, project_id, user_id, role, content,
           provider_code, model_name, created_at
    FROM messages
    WHERE project_id = $1
    ORDER BY created_at ASC
    `,
    [projectId]
  );
  return res.rows;
}

interface SendMessageInput {
  projectId: string;
  userId: string;
  userContent: string;
}

/**
 * Non-streaming send.
 */
export async function sendMessageToProject(input: SendMessageInput) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const project = await getProjectById(input.projectId);
    if (!project) throw new Error('Project not found');

    const provider = await getProviderById(project.provider_id);
    if (!provider || !provider.is_enabled) {
      throw new Error('Provider not found or disabled');
    }

    const model = await getModelById(project.model_id);
    if (!model || !model.is_enabled) {
      throw new Error('Model not found or disabled');
    }

    const keyRes = await client.query(
      `SELECT * FROM ai_provider_keys WHERE id = $1`,
      [project.provider_key_id]
    );
    if (!keyRes.rows.length) {
      throw new Error('Provider key not found');
    }
    const providerKey = keyRes.rows[0];

    if (
      providerKey.status !== 'active' ||
      providerKey.daily_usage >= providerKey.daily_limit
    ) {
      throw new Error("This chat's API key has reached its daily limit");
    }

    const historyRes = await client.query(
      `
      SELECT role, content
      FROM messages
      WHERE project_id = $1
      ORDER BY created_at ASC
      `,
      [input.projectId]
    );

    const history: ChatMessage[] = historyRes.rows.map((r) => ({
      role: r.role,
      content: r.content.text ?? r.content
    }));

    const userMessage: ChatMessage = { role: 'user', content: input.userContent };
    const messages: ChatMessage[] = [...history, userMessage];

    const adapter = getAdapter(provider.code);
    if (!adapter) {
      throw new Error(`No adapter configured for provider: ${provider.code}`);
    }

    const response = await adapter.sendChat({
      provider,
      providerKey,
      model: model.model_name,
      messages
    });

    const promptTokens = response.promptTokens ?? 0;
    const completionTokens = response.completionTokens ?? 0;
    const totalTokens =
      response.totalTokens ?? promptTokens + completionTokens;

    // store user message
    await client.query(
      `
      INSERT INTO messages (
        project_id, user_id, role, content, provider_code, model_name
      )
      VALUES ($1, $2, 'user', $3::jsonb, $4, $5)
      `,
      [
        input.projectId,
        input.userId,
        JSON.stringify({ text: input.userContent }),
        provider.code,
        model.model_name
      ]
    );

    // store assistant message
    const assistantInsert = await client.query(
      `
      INSERT INTO messages (
        project_id, user_id, role, content, provider_code, model_name
      )
      VALUES ($1, NULL, 'assistant', $2::jsonb, $3, $4)
      RETURNING id, created_at
      `,
      [
        input.projectId,
        JSON.stringify({ text: response.content }),
        provider.code,
        model.model_name
      ]
    );

    await client.query(
      `
      INSERT INTO usage_logs (
        user_id, project_id, provider_id, model_id, provider_key_id,
        tokens_in, tokens_out, cost
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      `,
      [
        input.userId,
        input.projectId,
        provider.id,
        model.id,
        providerKey.id,
        promptTokens,
        completionTokens,
        null
      ]
    );

    await incrementKeyUsage(providerKey.id, totalTokens);

    await client.query('COMMIT');

    return {
      content: response.content,
      tokens: {
        prompt: promptTokens,
        completion: completionTokens,
        total: totalTokens
      },
      messageId: assistantInsert.rows[0].id,
      created_at: assistantInsert.rows[0].created_at
    };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Streaming version: returns an async generator of ChatStreamChunk.
 */
export async function sendMessageToProjectStream(
  input: SendMessageInput
): Promise<AsyncGenerator<ChatStreamChunk, void, unknown>> {
  const client = await pool.connect();

  const project = await getProjectById(input.projectId);
  if (!project) {
    client.release();
    throw new Error('Project not found');
  }

  const provider = await getProviderById(project.provider_id);
  if (!provider || !provider.is_enabled) {
    client.release();
    throw new Error('Provider not found or disabled');
  }

  const model = await getModelById(project.model_id);
  if (!model || !model.is_enabled) {
    client.release();
    throw new Error('Model not found or disabled');
  }

  const keyRes = await client.query(
    `SELECT * FROM ai_provider_keys WHERE id = $1`,
    [project.provider_key_id]
  );
  if (!keyRes.rows.length) {
    client.release();
    throw new Error('Provider key not found');
  }
  const providerKey = keyRes.rows[0];

  if (
    providerKey.status !== 'active' ||
    providerKey.daily_usage >= providerKey.daily_limit
  ) {
    client.release();
    throw new Error("This chat's API key has reached its daily limit");
  }

  const historyRes = await client.query(
    `
    SELECT role, content
    FROM messages
    WHERE project_id = $1
    ORDER BY created_at ASC
    `,
    [input.projectId]
  );

  const history: ChatMessage[] = historyRes.rows.map((r) => ({
    role: r.role,
    content: r.content.text ?? r.content
  }));

  const userMessage: ChatMessage = { role: 'user', content: input.userContent };
  const messages: ChatMessage[] = [...history, userMessage];

  const adapter = getAdapter(provider.code);
  if (!adapter) {
    client.release();
    throw new Error(`No adapter configured for provider: ${provider.code}`);
  }

  const streamGenerator =
    adapter.sendChatStream?.({
      provider,
      providerKey,
      model: model.model_name,
      messages
    }) ??
    (async function* fallback() {
      const full = await adapter.sendChat({
        provider,
        providerKey,
        model: model.model_name,
        messages
      });

      yield {
        type: 'delta' as const,
        content: full.content
      };

      yield {
        type: 'done' as const,
        usage: {
          promptTokens: full.promptTokens,
          completionTokens: full.completionTokens,
          totalTokens: full.totalTokens
        }
      };
    })();

  async function* wrapper() {
    let finalText = '';
    let usage = { promptTokens: 0, completionTokens: 0, totalTokens: 0 };

    for await (const chunk of streamGenerator) {
      if (chunk.type === 'delta' && chunk.content) {
        finalText += chunk.content;
      }
      if (chunk.type === 'done' && chunk.usage) {
        usage = {
          promptTokens: chunk.usage.promptTokens ?? 0,
          completionTokens: chunk.usage.completionTokens ?? 0,
          totalTokens: chunk.usage.totalTokens ?? 0
        };
      }

      yield chunk;
    }

    try {
      await client.query('BEGIN');

      // user message
      await client.query(
        `
        INSERT INTO messages (
          project_id, user_id, role, content, provider_code, model_name
        )
        VALUES ($1, $2, 'user', $3::jsonb, $4, $5)
        `,
        [
          input.projectId,
          input.userId,
          JSON.stringify({ text: input.userContent }),
          provider.code,
          model.model_name
        ]
      );

      // assistant message
      await client.query(
        `
        INSERT INTO messages (
          project_id, user_id, role, content, provider_code, model_name
        )
        VALUES ($1, NULL, 'assistant', $2::jsonb, $3, $4)
        `,
        [
          input.projectId,
          JSON.stringify({ text: finalText }),
          provider.code,
          model.model_name
        ]
      );

      // usage log
      await client.query(
        `
        INSERT INTO usage_logs (
          user_id, project_id, provider_id, model_id, provider_key_id,
          tokens_in, tokens_out, cost
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
        `,
        [
          input.userId,
          input.projectId,
          provider.id,
          model.id,
          providerKey.id,
          usage.promptTokens,
          usage.completionTokens,
          null
        ]
      );

      await incrementKeyUsage(providerKey.id, usage.totalTokens);

      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      console.error('[Stream] Failed to persist messages/usage:', err);
    } finally {
      client.release();
    }
  }

  return wrapper();
}
