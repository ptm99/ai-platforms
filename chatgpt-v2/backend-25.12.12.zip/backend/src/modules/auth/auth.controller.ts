// src/modules/auth/auth.controller.ts

import { Router, Request, Response } from 'express';
import { authRequired, requireRole, AuthUser } from '../../middleware/auth.middleware';
import {
  registerUser,
  loginUser,
  refreshTokens,
  logout,
  getUserById,
  listUsers,
  updateUserRole,
  UserRole
} from './auth.service';

export const authRouter = Router();

interface AuthenticatedRequest extends Request {
  user: AuthUser;
}

// ----------------- PUBLIC ROUTES -----------------

// POST /auth/register
authRouter.post('/register', async (req: Request, res: Response) => {
  try {
    const { email, password, display_name } = req.body;

    if (!email || !password) {
      return res
        .status(400)
        .json({ error: 'email and password are required' });
    }

    const userAgent = req.headers['user-agent'] || '';
    const ip =
      (req.headers['x-forwarded-for'] as string) ||
      (req.socket.remoteAddress ?? '');

    const result = await registerUser({
      email,
      password,
      display_name,
      userAgent,
      ip
    });

    res.status(201).json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Registration failed' });
  }
});

// POST /auth/login
authRouter.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res
        .status(400)
        .json({ error: 'email and password are required' });
    }

    const userAgent = req.headers['user-agent'] || '';
    const ip =
      (req.headers['x-forwarded-for'] as string) ||
      (req.socket.remoteAddress ?? '');

    const result = await loginUser({
      email,
      password,
      userAgent,
      ip
    });

    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Login failed' });
  }
});

// POST /auth/refresh
authRouter.post('/refresh', async (req: Request, res: Response) => {
  try {
    const { refreshToken } = req.body;

    const userAgent = req.headers['user-agent'] || '';
    const ip =
      (req.headers['x-forwarded-for'] as string) ||
      (req.socket.remoteAddress ?? '');

    const result = await refreshTokens({
      refreshToken,
      userAgent,
      ip
    });

    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Refresh failed' });
  }
});

// POST /auth/logout
authRouter.post('/logout', async (req: Request, res: Response) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) {
      await logout({ refreshToken });
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Logout failed' });
  }
});

// ----------------- AUTHENTICATED ROUTES -----------------

authRouter.get('/me', authRequired, async (req: Request, res: Response) => {
  const authReq = req as AuthenticatedRequest;
  try {
    const user = await getUserById(authReq.user.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json({ user });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to load profile' });
  }
});

// ----------------- ADMIN ROUTES -----------------

// GET /auth/admin/users
authRouter.get(
  '/admin/users',
  authRequired,
  requireRole('admin'),
  async (_req: Request, res: Response) => {
    try {
      const users = await listUsers();
      res.json(users);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to list users' });
    }
  }
);

// PATCH /auth/admin/users/:id/role
authRouter.patch(
  '/admin/users/:id/role',
  authRequired,
  requireRole('superadmin'),
  async (req: Request, res: Response) => {
    try {
      const targetId = req.params.id;
      const { role } = req.body as { role: UserRole };

      if (!['user', 'admin', 'superadmin'].includes(role)) {
        return res.status(400).json({ error: 'Invalid role' });
      }

      const updated = await updateUserRole(targetId, role);
      res.json(updated);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to update role' });
    }
  }
);
