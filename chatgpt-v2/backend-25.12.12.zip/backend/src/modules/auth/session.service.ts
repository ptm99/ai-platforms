// src/modules/auth/session.service.ts

import { pool } from '../../db/pool';
import crypto from 'crypto';

const REFRESH_TOKEN_TTL_DAYS = parseInt(
  process.env.REFRESH_TOKEN_TTL_DAYS || '30',
  10
);

function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export interface UserSession {
  id: string;
  user_id: string;
  refresh_token_hash: string;
  user_agent: string | null;
  ip_address: string | null;
  created_at: string;
  expires_at: string;
  revoked_at: string | null;
  last_refreshed_at: string | null;
}

/**
 * Create a new session row, return { sessionId, hashedTokenWriter }.
 * The caller is responsible for signing a refresh JWT with this sessionId,
 * then calling setSessionTokenHash to store the hash.
 */
export async function createEmptySession(
  userId: string | number,
  userAgent?: string,
  ip?: string
): Promise<{ sessionId: string; expiresAt: Date }> {
  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL_DAYS * 86400000);

  const res = await pool.query(
    `
    INSERT INTO user_sessions (
      user_id, refresh_token_hash, user_agent, ip_address, expires_at
    )
    VALUES ($1, '', $2, $3, $4)
    RETURNING id, expires_at
    `,
    [userId, userAgent ?? null, ip ?? null, expiresAt]
  );

  return {
    sessionId: String(res.rows[0].id),
    expiresAt: res.rows[0].expires_at
  };
}

/**
 * After we have the actual refresh token, store its hash.
 */
export async function setSessionTokenHash(
  sessionId: string | number,
  refreshToken: string
): Promise<void> {
  const hash = hashToken(refreshToken);
  await pool.query(
    `
    UPDATE user_sessions
    SET refresh_token_hash = $2
    WHERE id = $1
    `,
    [sessionId, hash]
  );
}

/**
 * Load a session, validating basic properties (not revoked, not expired).
 */
export async function getActiveSessionById(
  sessionId: string | number
): Promise<UserSession | null> {
  const res = await pool.query(
    `
    SELECT *
    FROM user_sessions
    WHERE id = $1
      AND revoked_at IS NULL
      AND expires_at > NOW()
    `,
    [sessionId]
  );

  if (!res.rows.length) return null;
  return res.rows[0];
}

/**
 * On refresh, verify the presented token matches the stored hash.
 * If mismatch, revoke the session (possible theft/replay).
 */
export async function validateSessionRefreshToken(
  session: UserSession,
  presentedToken: string
): Promise<boolean> {
  const presentedHash = hashToken(presentedToken);
  if (presentedHash !== session.refresh_token_hash) {
    // revoke this session immediately
    await revokeSession(session.id);
    return false;
  }
  return true;
}

/**
 * Rotate refresh token: update hash and expiry, mark last_refreshed_at.
 */
export async function rotateSessionToken(
  sessionId: string | number,
  newRefreshToken: string
): Promise<void> {
  const newHash = hashToken(newRefreshToken);
  const newExpiresAt = new Date(
    Date.now() + REFRESH_TOKEN_TTL_DAYS * 86400000
  );

  await pool.query(
    `
    UPDATE user_sessions
    SET refresh_token_hash = $2,
        expires_at = $3,
        last_refreshed_at = NOW()
    WHERE id = $1
      AND revoked_at IS NULL
    `,
    [sessionId, newHash, newExpiresAt]
  );
}

/**
 * Revoke a single session.
 */
export async function revokeSession(
  sessionId: string | number
): Promise<void> {
  await pool.query(
    `
    UPDATE user_sessions
    SET revoked_at = NOW()
    WHERE id = $1
      AND revoked_at IS NULL
    `,
    [sessionId]
  );
}

/**
 * Revoke all sessions for a given user (e.g. force logout from all devices).
 */
export async function revokeAllSessionsForUser(
  userId: string | number
): Promise<void> {
  await pool.query(
    `
    UPDATE user_sessions
    SET revoked_at = NOW()
    WHERE user_id = $1
      AND revoked_at IS NULL
    `,
    [userId]
  );
}
