// src/modules/auth/auth.service.ts

import { pool } from '../../db/pool';
import { hashPassword, verifyPassword } from '../../utils/password.util';
import {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  RefreshTokenPayload
} from '../../utils/jwt.util';
import {
  createEmptySession,
  setSessionTokenHash,
  getActiveSessionById,
  validateSessionRefreshToken,
  rotateSessionToken,
  revokeSession
} from './session.service';

export type UserRole = 'user' | 'admin' | 'superadmin';

export interface UserRecord {
  id: string;
  email: string;
  display_name: string | null;
  role: UserRole;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface AuthResult {
  user: UserRecord;
  tokens: AuthTokens;
}

/**
 * Get user by email.
 */
async function getUserByEmail(email: string): Promise<UserRecord | null> {
  const res = await pool.query(
    `
    SELECT id, email, display_name, role, is_active, created_at, updated_at, password_hash
    FROM users
    WHERE email = $1
    `,
    [email.toLowerCase()]
  );
  if (!res.rows.length) return null;
  return res.rows[0];
}

/**
 * Get user by id.
 */
export async function getUserById(id: string | number): Promise<UserRecord | null> {
  const res = await pool.query(
    `
    SELECT id, email, display_name, role, is_active, created_at, updated_at
    FROM users
    WHERE id = $1
    `,
    [id]
  );
  if (!res.rows.length) return null;
  return res.rows[0];
}

/**
 * Helper to strip password_hash from user row.
 */
function sanitizeUserRow(row: any): UserRecord {
  return {
    id: String(row.id),
    email: row.email,
    display_name: row.display_name,
    role: row.role,
    is_active: row.is_active,
    created_at: row.created_at,
    updated_at: row.updated_at
  };
}

/**
 * Determine role for a newly registered user.
 * First user in system becomes superadmin, others become user.
 */
async function determineNewUserRole(): Promise<UserRole> {
  const res = await pool.query(`SELECT COUNT(*) AS count FROM users`);
  const count = Number(res.rows[0].count);
  if (count === 0) return 'superadmin';
  return 'user';
}

/**
 * Register a new user + create initial session + tokens.
 */
export async function registerUser(input: {
  email: string;
  password: string;
  display_name?: string;
  userAgent?: string;
  ip?: string;
}): Promise<AuthResult> {
  const email = input.email.toLowerCase();

  const existing = await getUserByEmail(email);
  if (existing) {
    throw new Error('Email is already registered');
  }

  const passwordHash = await hashPassword(input.password);
  const role = await determineNewUserRole();

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const insertRes = await client.query(
      `
      INSERT INTO users (email, password_hash, display_name, role)
      VALUES ($1, $2, $3, $4)
      RETURNING id, email, display_name, role, is_active, created_at, updated_at
      `,
      [email, passwordHash, input.display_name ?? null, role]
    );

    const userRow = insertRes.rows[0];
    const user = sanitizeUserRow(userRow);

    // Create a session row without hash first
    const session = await createEmptySession(
      user.id,
      input.userAgent,
      input.ip
    );

    // Sign refresh token with session id
    const refreshToken = signRefreshToken(user.id, session.sessionId);

    // Store hash for the refresh token
    await setSessionTokenHash(session.sessionId, refreshToken);

    const accessToken = signAccessToken({
      id: user.id,
      role: user.role
    });

    await client.query('COMMIT');

    return {
      user,
      tokens: {
        accessToken,
        refreshToken
      }
    };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Login existing user + create new session + tokens.
 */
export async function loginUser(input: {
  email: string;
  password: string;
  userAgent?: string;
  ip?: string;
}): Promise<AuthResult> {
  const email = input.email.toLowerCase();

  const res = await pool.query(
    `
    SELECT id, email, display_name, role, is_active, created_at, updated_at, password_hash
    FROM users
    WHERE email = $1
    `,
    [email]
  );

  if (!res.rows.length) {
    throw new Error('Invalid email or password');
  }

  const row = res.rows[0];

  if (!row.is_active) {
    throw new Error('User account is inactive');
  }

  const ok = await verifyPassword(input.password, row.password_hash);
  if (!ok) {
    throw new Error('Invalid email or password');
  }

  const user = sanitizeUserRow(row);

  const session = await createEmptySession(
    user.id,
    input.userAgent,
    input.ip
  );

  const refreshToken = signRefreshToken(user.id, session.sessionId);
  await setSessionTokenHash(session.sessionId, refreshToken);

  const accessToken = signAccessToken({
    id: user.id,
    role: user.role
  });

  return {
    user,
    tokens: { accessToken, refreshToken }
  };
}

/**
 * Refresh tokens: verify refresh JWT, validate session, rotate token, return new tokens.
 */
export async function refreshTokens(input: {
  refreshToken: string;
  userAgent?: string;
  ip?: string;
}): Promise<AuthResult> {
  if (!input.refreshToken) {
    throw new Error('refreshToken is required');
  }

  let payload: RefreshTokenPayload;
  try {
    payload = verifyRefreshToken(input.refreshToken);
  } catch (err: any) {
    throw new Error('Invalid or expired refresh token');
  }

  const session = await getActiveSessionById(payload.sid);
  if (!session) {
    throw new Error('Session not found or expired');
  }

  if (String(session.user_id) !== String(payload.sub)) {
    await revokeSession(session.id);
    throw new Error('Refresh token does not match session user');
  }

  const stillValid = await validateSessionRefreshToken(
    session,
    input.refreshToken
  );
  if (!stillValid) {
    throw new Error('Refresh token has been rotated or revoked');
  }

  // Load user
  const user = await getUserById(payload.sub);
  if (!user || !user.is_active) {
    await revokeSession(session.id);
    throw new Error('User not found or inactive');
  }

  const newRefreshToken = signRefreshToken(user.id, session.id);
  await rotateSessionToken(session.id, newRefreshToken);

  const accessToken = signAccessToken({
    id: user.id,
    role: user.role
  });

  return {
    user,
    tokens: {
      accessToken,
      refreshToken: newRefreshToken
    }
  };
}

/**
 * Logout: revoke a single session based on refresh token.
 */
export async function logout(input: { refreshToken: string }): Promise<void> {
  if (!input.refreshToken) return;

  let payload: RefreshTokenPayload;
  try {
    payload = verifyRefreshToken(input.refreshToken);
  } catch {
    // Invalid token; nothing to revoke
    return;
  }

  await revokeSession(payload.sid);
}

/**
 * Admin: list users.
 */
export async function listUsers(): Promise<UserRecord[]> {
  const res = await pool.query(
    `
    SELECT id, email, display_name, role, is_active, created_at, updated_at
    FROM users
    ORDER BY created_at ASC
    `
  );
  return res.rows.map(sanitizeUserRow);
}

/**
 * Admin: update user role.
 */
export async function updateUserRole(
  targetUserId: string | number,
  newRole: UserRole
): Promise<UserRecord> {
  const res = await pool.query(
    `
    UPDATE users
    SET role = $2,
        updated_at = NOW()
    WHERE id = $1
    RETURNING id, email, display_name, role, is_active, created_at, updated_at
    `,
    [targetUserId, newRole]
  );

  if (!res.rows.length) {
    throw new Error('User not found');
  }

  return sanitizeUserRow(res.rows[0]);
}
