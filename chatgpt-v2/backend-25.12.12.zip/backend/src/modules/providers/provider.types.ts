// src/modules/providers/provider.types.ts

export interface AIProvider {
  id: string;
  code: string;
  display_name: string;
  adapter_file: string;
  is_enabled: boolean;
  created_at: string;
  updated_at: string;
}

export interface AIProviderModel {
  id: string;
  provider_id: string;
  model_name: string;
  is_enabled: boolean;
  context_length: number | null;
  created_at: string;
}

export type KeyStatus = 'active' | 'exhausted' | 'disabled';

export interface ProviderKey {
  id: string;
  provider_id: string;
  model_id: string;
  api_key_enc: string;
  name: string | null;
  status: KeyStatus;
  daily_limit: number;
  daily_usage: number;
  last_reset_at: string;
  last_used_at: string | null;
  created_at: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface ChatRequest {
  provider: AIProvider;
  providerKey: ProviderKey;
  model: string;
  messages: ChatMessage[];
}

export interface ChatResponse {
  content: string;
  promptTokens?: number;
  completionTokens?: number;
  totalTokens?: number;
}

export interface ChatStreamChunk {
  type: 'delta' | 'done' | 'error';
  content?: string;
  usage?: {
    promptTokens?: number;
    completionTokens?: number;
    totalTokens?: number;
  };
  raw?: any;
}
