// src/modules/providers/keySelector.service.ts

import { pool } from '../../db/pool';
import { ProviderKey } from './provider.types';

/**
 * Select the lowest-usage active key for a given model.
 */
export async function selectKeyForModel(modelId: string): Promise<ProviderKey> {
  const res = await pool.query(
    `
    SELECT *
    FROM ai_provider_keys
    WHERE model_id = $1
      AND status = 'active'
      AND daily_usage < daily_limit
    ORDER BY daily_usage ASC,
             last_used_at NULLS FIRST
    LIMIT 1
    `,
    [modelId]
  );

  if (!res.rows.length) {
    throw new Error('No available API key for this model');
  }

  return res.rows[0];
}

/**
 * Increment usage for a key (tokens).
 */
export async function incrementKeyUsage(
  keyId: string,
  tokenCount: number
): Promise<void> {
  await pool.query(
    `
    UPDATE ai_provider_keys
    SET daily_usage = daily_usage + $1,
        last_used_at = NOW()
    WHERE id = $2
    `,
    [tokenCount, keyId]
  );
}

/**
 * Reset usage at midnight (used by cron).
 */
export async function resetDailyUsageForAllKeys(): Promise<void> {
  await pool.query(
    `
    UPDATE ai_provider_keys
    SET daily_usage = 0,
        status = 'active',
        last_reset_at = CURRENT_DATE
    `
  );
}
