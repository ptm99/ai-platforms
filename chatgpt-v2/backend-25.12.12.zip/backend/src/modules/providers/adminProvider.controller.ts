// backend/src/modules/providers/adminProvider.controller.ts

import { Router, Request, Response } from 'express';
import { authRequired } from '../../middleware/auth.middleware';
import { requireRole } from '../../middleware/role.middleware';
import { encrypt } from '../../utils/crypto';
import { pool } from '../../db/pool';
import {
  getAllProviders,
  createProvider,
  updateProvider,
  deleteProvider,
  listModelsForProvider,
  createModel,
  updateModel,
  deleteModel,
  listKeysForModel
} from './provider.service';

export const adminProviderRouter = Router();

// All admin routes require auth + admin or super_admin
adminProviderRouter.use(authRequired);
adminProviderRouter.use(requireRole('admin'));


/* ---------------------- PROVIDERS CRUD ---------------------- */

// GET /admin/providers
adminProviderRouter.get('/admin/providers', async (_req: Request, res: Response) => {
  try {
    const providers = await getAllProviders();
    res.json(providers);
  } catch {
    res.status(500).json({ error: 'Failed to fetch providers' });
  }
});

// POST /admin/providers
adminProviderRouter.post('/admin/providers', async (req: Request, res: Response) => {
  try {
    const { code, display_name, adapter_file, description, logo_url } = req.body;

    if (!code || !display_name || !adapter_file) {
      return res
        .status(400)
        .json({ error: 'code, display_name and adapter_file are required' });
    }

    const provider = await createProvider({
      code,
      display_name,
      adapter_file,
      description,
      logo_url
    });

    res.status(201).json(provider);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to create provider' });
  }
});

// PATCH /admin/providers/:id
adminProviderRouter.patch('/admin/providers/:id', async (req: Request, res: Response) => {
  try {
    const provider = await updateProvider(req.params.id, req.body);
    if (!provider) {
      return res.status(404).json({ error: 'Provider not found' });
    }
    res.json(provider);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to update provider' });
  }
});

// DELETE /admin/providers/:id
adminProviderRouter.delete('/admin/providers/:id', async (req: Request, res: Response) => {
  try {
    await deleteProvider(req.params.id);
    res.status(204).send();
  } catch {
    res.status(400).json({ error: 'Failed to delete provider' });
  }
});


/* ---------------------- MODELS CRUD ------------------------- */

// GET /admin/providers/:providerId/models
adminProviderRouter.get(
  '/admin/providers/:providerId/models',
  async (req: Request, res: Response) => {
    try {
      const models = await listModelsForProvider(req.params.providerId);
      res.json(models);
    } catch {
      res.status(500).json({ error: 'Failed to fetch models' });
    }
  }
);

// POST /admin/providers/:providerId/models
adminProviderRouter.post(
  '/admin/providers/:providerId/models',
  async (req: Request, res: Response) => {
    try {
      const provider_id = req.params.providerId;
      const { model_name, context_length } = req.body;

      if (!model_name) {
        return res.status(400).json({ error: 'model_name is required' });
      }

      const model = await createModel({
        provider_id,
        model_name,
        context_length
      });

      res.status(201).json(model);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to create model' });
    }
  }
);

// PATCH /admin/models/:id
adminProviderRouter.patch('/admin/models/:id', async (req: Request, res: Response) => {
  try {
    const model = await updateModel(req.params.id, req.body);
    if (!model) {
      return res.status(404).json({ error: 'Model not found' });
    }
    res.json(model);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to update model' });
  }
});

// DELETE /admin/models/:id
adminProviderRouter.delete('/admin/models/:id', async (req: Request, res: Response) => {
  try {
    await deleteModel(req.params.id);
    res.status(204).send();
  } catch {
    res.status(400).json({ error: 'Failed to delete model' });
  }
});


/* ---------------------- KEYS CRUD --------------------------- */

// GET /admin/models/:modelId/keys
adminProviderRouter.get('/admin/models/:modelId/keys', async (req: Request, res: Response) => {
  try {
    const keys = await listKeysForModel(req.params.modelId);
    res.json(keys);
  } catch {
    res.status(500).json({ error: 'Failed to fetch keys' });
  }
});

// POST /admin/models/:modelId/keys
adminProviderRouter.post('/admin/models/:modelId/keys', async (req: Request, res: Response) => {
  try {
    const modelId = req.params.modelId;
    const { provider_id, api_key, name, daily_limit } = req.body;

    if (!provider_id || !api_key || !daily_limit) {
      return res
        .status(400)
        .json({ error: 'provider_id, api_key and daily_limit are required' });
    }

    const encrypted = encrypt(api_key);

    const result = await pool.query(
      `
      INSERT INTO ai_provider_keys (
        provider_id, model_id, api_key_enc, name, daily_limit
      )
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *
      `,
      [provider_id, modelId, encrypted, name ?? null, daily_limit]
    );

    res.status(201).json(result.rows[0]);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to create key' });
  }
});

// PATCH /admin/provider-keys/:id
adminProviderRouter.patch(
  '/admin/provider-keys/:id',
  async (req: Request, res: Response) => {
    try {
      const { status, daily_limit, name } = req.body;
      const result = await pool.query(
        `
        UPDATE ai_provider_keys
        SET status      = COALESCE($2, status),
            daily_limit = COALESCE($3, daily_limit),
            name        = COALESCE($4, name),
            updated_at  = NOW()
        WHERE id = $1
        RETURNING *
        `,
        [req.params.id, status ?? null, daily_limit ?? null, name ?? null]
      );

      if (!result.rows.length) {
        return res.status(404).json({ error: 'Key not found' });
      }

      res.json(result.rows[0]);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to update key' });
    }
  }
);

// DELETE /admin/provider-keys/:id
adminProviderRouter.delete(
  '/admin/provider-keys/:id',
  async (req: Request, res: Response) => {
    try {
      await pool.query('DELETE FROM ai_provider_keys WHERE id = $1', [
        req.params.id
      ]);
      res.status(204).send();
    } catch {
      res.status(400).json({ error: 'Failed to delete key' });
    }
  }
);


/* -------------------- KEY USAGE ANALYTICS ------------------- */

// GET /admin/provider-status
adminProviderRouter.get('/admin/provider-status', async (_req: Request, res: Response) => {
  try {
    const result = await pool.query(
      `
      SELECT
        p.id          AS provider_id,
        p.code        AS provider_code,
        p.display_name,
        m.id          AS model_id,
        m.model_name,
        COUNT(k.*)                                                AS total_keys,
        SUM(CASE WHEN k.status = 'active' THEN 1 ELSE 0 END)      AS active_keys,
        SUM(CASE WHEN k.status = 'exhausted' THEN 1 ELSE 0 END)   AS exhausted_keys,
        SUM(CASE WHEN k.status = 'disabled' THEN 1 ELSE 0 END)    AS disabled_keys,
        SUM(CASE WHEN
              k.status = 'active'
              AND k.daily_limit > 0
              AND (k.daily_usage::decimal / k.daily_limit) >= 0.90
            THEN 1 ELSE 0 END)                                   AS near_limit_keys
      FROM ai_providers p
      JOIN ai_provider_models m ON m.provider_id = p.id
      LEFT JOIN ai_provider_keys k ON k.model_id = m.id
      GROUP BY p.id, p.code, p.display_name, m.id, m.model_name
      ORDER BY p.display_name, m.model_name
      `
    );

    res.json(
      result.rows.map((row) => ({
        provider: {
          id: row.provider_id,
          code: row.provider_code,
          name: row.display_name
        },
        model: {
          id: row.model_id,
          name: row.model_name
        },
        keys: {
          total: Number(row.total_keys),
          active: Number(row.active_keys),
          exhausted: Number(row.exhausted_keys),
          disabled: Number(row.disabled_keys),
          near_limit: Number(row.near_limit_keys)
        }
      }))
    );
  } catch (err: any) {
    res.status(500).json({
      error: err.message || 'Failed to compute provider status'
    });
  }
});
