// backend/src/modules/providers/testProviderAdapters.ts

import 'dotenv/config';
import { pool } from '../../db/pool';
import { loadAdapters, getAdapter } from './adapters/adapterLoader';
import { decrypt } from '../../utils/crypto';
import { ChatMessage } from './provider.types';

async function getOneActiveKeyWithModel() {
  const res = await pool.query(
    `
    SELECT
      p.id          AS provider_id,
      p.code        AS provider_code,
      p.display_name,
      m.id          AS model_id,
      m.model_name,
      k.id          AS key_id,
      k.api_key_enc
    FROM ai_provider_keys k
    JOIN ai_provider_models m ON m.id = k.model_id
    JOIN ai_providers p       ON p.id = k.provider_id
    WHERE k.status = 'active'
      AND k.daily_usage < k.daily_limit
      AND p.is_enabled = TRUE
      AND m.is_enabled = TRUE
    ORDER BY p.display_name, m.model_name, k.created_at
    LIMIT 1
    `
  );

  if (!res.rows.length) {
    throw new Error('No active provider/model/key available in database.');
  }

  return res.rows[0];
}

async function runSingleTest() {
  console.log('Loading adapters from DB...');
  await loadAdapters();

  const row = await getOneActiveKeyWithModel();
  console.log('Using:');
  console.log(`  Provider: ${row.display_name} (${row.provider_code})`);
  console.log(`  Model:    ${row.model_name}`);
  console.log(`  Key ID:   ${row.key_id}`);

  const adapter = getAdapter(row.provider_code);
  if (!adapter) {
    throw new Error(`No adapter loaded for provider code: ${row.provider_code}`);
  }

  const messages: ChatMessage[] = [
    { role: 'system', content: 'You are a test assistant.' },
    { role: 'user', content: 'Say a short hello message.' }
  ];

  const provider = {
    id: row.provider_id,
    code: row.provider_code,
    display_name: row.display_name,
    adapter_file: '',
    is_enabled: true,
    created_at: '',
    updated_at: ''
  };

  const providerKey = {
    id: row.key_id,
    provider_id: row.provider_id,
    model_id: row.model_id,
    api_key_enc: row.api_key_enc,
    name: null,
    status: 'active' as const,
    daily_limit: 100000,
    daily_usage: 0,
    last_reset_at: '',
    last_used_at: null,
    created_at: ''
  };

  console.log('Sending test chat request...');
  const result = await adapter.sendChat({
    provider,
    providerKey,
    model: row.model_name,
    messages
  });

  console.log('--- Response ---');
  console.log(result.content);
  console.log('--- Usage ---');
  console.log({
    promptTokens: result.promptTokens,
    completionTokens: result.completionTokens,
    totalTokens: result.totalTokens
  });
}

runSingleTest()
  .then(() => {
    console.log('Adapter test completed successfully.');
    process.exit(0);
  })
  .catch((err) => {
    console.error('Adapter test FAILED:', err);
    process.exit(1);
  });
