import { Router, Request, Response } from 'express';
import { getEnabledProviders } from './provider.service';
import { authRequired } from '../../middleware/auth.middleware';

export const providerRouter = Router();

// Could be public or authRequired; here we require auth
providerRouter.use(authRequired);

providerRouter.get('/enabled', async (_req: Request, res: Response) => {
  try {
    const providers = await getEnabledProviders();
    res.json(providers);
  } catch {
    res.status(500).json({ error: 'Failed to load providers' });
  }
});
