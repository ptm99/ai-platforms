// src/modules/providers/provider.service.ts

import { pool } from '../../db/pool';
import {
  AIProvider,
  AIProviderModel,
  ProviderKey
} from './provider.types';

export async function getAllProviders(): Promise<AIProvider[]> {
  const res = await pool.query(`
    SELECT *
    FROM ai_providers
    ORDER BY display_name ASC
  `);
  return res.rows;
}

export async function getEnabledProviders(): Promise<AIProvider[]> {
  const res = await pool.query(`
    SELECT *
    FROM ai_providers
    WHERE is_enabled = TRUE
    ORDER BY display_name ASC
  `);
  return res.rows;
}

export async function getProviderById(id: string): Promise<AIProvider | null> {
  const res = await pool.query(
    `SELECT * FROM ai_providers WHERE id = $1`,
    [id]
  );
  return res.rows[0] ?? null;
}

export async function getProviderByCode(code: string): Promise<AIProvider | null> {
  const res = await pool.query(
    `SELECT * FROM ai_providers WHERE code = $1`,
    [code]
  );
  return res.rows[0] ?? null;
}

export async function createProvider(input: {
  code: string;
  display_name: string;
  adapter_file: string;
  description?: string;
  logo_url?: string;
}): Promise<AIProvider> {
  const res = await pool.query(
    `
    INSERT INTO ai_providers (
      code, display_name, adapter_file, is_enabled, description, logo_url
    )
    VALUES ($1, $2, $3, TRUE, $4, $5)
    RETURNING *
    `,
    [
      input.code,
      input.display_name,
      input.adapter_file,
      input.description ?? null,
      input.logo_url ?? null
    ]
  );
  return res.rows[0];
}

export async function updateProvider(
  id: string,
  data: Partial<AIProvider> & { description?: string; logo_url?: string }
): Promise<AIProvider | null> {
  const res = await pool.query(
    `
    UPDATE ai_providers
    SET display_name = COALESCE($2, display_name),
        adapter_file = COALESCE($3, adapter_file),
        is_enabled   = COALESCE($4, is_enabled),
        description  = COALESCE($5, description),
        logo_url     = COALESCE($6, logo_url),
        updated_at   = NOW()
    WHERE id = $1
    RETURNING *
    `,
    [
      id,
      data.display_name ?? null,
      data.adapter_file ?? null,
      typeof data.is_enabled === 'boolean' ? data.is_enabled : null,
      data['description'] ?? null,
      data['logo_url'] ?? null
    ]
  );
  return res.rows[0] ?? null;
}

export async function deleteProvider(id: string): Promise<void> {
  await pool.query('DELETE FROM ai_providers WHERE id = $1', [id]);
}

/* MODELS */

export async function listModelsForProvider(
  providerId: string
): Promise<AIProviderModel[]> {
  const res = await pool.query(
    `
    SELECT *
    FROM ai_provider_models
    WHERE provider_id = $1
    ORDER BY model_name ASC
    `,
    [providerId]
  );
  return res.rows;
}

export async function getModelById(
  id: string
): Promise<AIProviderModel | null> {
  const res = await pool.query(
    `
    SELECT *
    FROM ai_provider_models
    WHERE id = $1
    `,
    [id]
  );
  return res.rows[0] ?? null;
}

export async function createModel(input: {
  provider_id: string;
  model_name: string;
  context_length?: number | null;
}): Promise<AIProviderModel> {
  const res = await pool.query(
    `
    INSERT INTO ai_provider_models (provider_id, model_name, context_length, is_enabled)
    VALUES ($1, $2, $3, TRUE)
    RETURNING *
    `,
    [input.provider_id, input.model_name, input.context_length ?? null]
  );
  return res.rows[0];
}

export async function updateModel(
  id: string,
  data: Partial<AIProviderModel>
): Promise<AIProviderModel | null> {
  const res = await pool.query(
    `
    UPDATE ai_provider_models
    SET model_name     = COALESCE($2, model_name),
        context_length = COALESCE($3, context_length),
        is_enabled     = COALESCE($4, is_enabled)
    WHERE id = $1
    RETURNING *
    `,
    [
      id,
      data.model_name ?? null,
      data.context_length ?? null,
      typeof data.is_enabled === 'boolean' ? data.is_enabled : null
    ]
  );
  return res.rows[0] ?? null;
}

export async function deleteModel(id: string): Promise<void> {
  await pool.query('DELETE FROM ai_provider_models WHERE id = $1', [id]);
}

/* KEYS */

export async function listKeysForModel(modelId: string): Promise<ProviderKey[]> {
  const res = await pool.query(
    `
    SELECT *
    FROM ai_provider_keys
    WHERE model_id = $1
    ORDER BY created_at DESC
    `,
    [modelId]
  );
  return res.rows;
}

export async function getKeyById(id: string): Promise<ProviderKey | null> {
  const res = await pool.query(
    `SELECT * FROM ai_provider_keys WHERE id = $1`,
    [id]
  );
  return res.rows[0] ?? null;
}
