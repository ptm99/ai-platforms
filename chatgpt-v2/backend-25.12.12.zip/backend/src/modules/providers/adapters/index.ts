import { ProviderAdapter } from './baseAdapter';
import { OpenAIAdapter } from './openai.adapter';
import { config } from '../../../config';

const encryptionSecret = config.apiKeyEncryptionSecret;

// Stubs for other providers can be added similar to OpenAIAdapter
export const providerAdapters: Record<string, ProviderAdapter> = {
  openai: new OpenAIAdapter(encryptionSecret)
  // claude: new ClaudeAdapter(encryptionSecret),
  // deepseek: new DeepseekAdapter(encryptionSecret),
  // gemini: new GeminiAdapter(encryptionSecret),
};
