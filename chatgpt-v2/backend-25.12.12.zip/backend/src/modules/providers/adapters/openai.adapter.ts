// backend/src/modules/providers/adapters/openai.adapter.ts

import fetch from 'node-fetch';
import { ProviderAdapter } from './baseAdapter';
import {
  ChatRequest,
  ChatResponse,
  ChatStreamChunk
} from '../provider.types';
import { decrypt } from '../../../utils/crypto';
import { fetchJson } from './httpClient';

export class OpenAIAdapter implements ProviderAdapter {
  constructor(private encryptionKey: string) {}

  /**
   * Non-streaming call — standard chat completion
   */
  async sendChat(req: ChatRequest): Promise<ChatResponse> {
    const apiKey = decrypt(req.providerKey.api_key_enc);
    const url = 'https://api.openai.com/v1/chat/completions';

    const body = {
      model: req.model,
      messages: req.messages.map((m) => ({
        role: m.role,
        content: m.content
      }))
    };

    const json = await fetchJson(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    return {
      content: json.choices[0].message.content,
      promptTokens: json.usage?.prompt_tokens ?? 0,
      completionTokens: json.usage?.completion_tokens ?? 0,
      totalTokens: json.usage?.total_tokens ?? 0
    };
  }

  /**
   * True streaming implementation using SSE.
   * Yields small text deltas as they arrive.
   */
  async *sendChatStream(
    req: ChatRequest
  ): AsyncGenerator<ChatStreamChunk, void, unknown> {
    const apiKey = decrypt(req.providerKey.api_key_enc);
    const url = 'https://api.openai.com/v1/chat/completions';

    const body = {
      model: req.model,
      stream: true,
      messages: req.messages.map((m) => ({
        role: m.role,
        content: m.content
      }))
    };

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    if (!res.ok || !res.body) {
      const text = await res.text();
      throw new Error(
        `OpenAI streaming request failed (${res.status}): ${text || 'Unknown error'}`
      );
    }

    let buffer = '';
    let finalUsage: {
      promptTokens?: number;
      completionTokens?: number;
      totalTokens?: number;
    } = {};

    // Node-fetch body is an async iterable (Buffer chunks)
    for await (const chunk of res.body as any) {
      const text = chunk.toString('utf8');
      buffer += text;

      // Process complete SSE events separated by double newline
      let sepIndex: number;
      while ((sepIndex = buffer.indexOf('\n\n')) !== -1) {
        const rawEvent = buffer.slice(0, sepIndex).trim();
        buffer = buffer.slice(sepIndex + 2);

        if (!rawEvent) continue;

        const lines = rawEvent
          .split('\n')
          .map((l) => l.trim())
          .filter(Boolean);

        for (const line of lines) {
          if (!line.startsWith('data:')) continue;

          const dataStr = line.slice('data:'.length).trim();
          if (dataStr === '[DONE]') {
            // End of stream
            yield {
              type: 'done',
              usage: finalUsage
            };
            return;
          }

          let parsed: any;
          try {
            parsed = JSON.parse(dataStr);
          } catch {
            // Ignore malformed JSON lines
            continue;
          }

          const choice = parsed.choices?.[0];

          // Newer OpenAI streaming responses may include usage in final chunk
          if (parsed.usage) {
            finalUsage = {
              promptTokens: parsed.usage?.prompt_tokens ?? finalUsage.promptTokens,
              completionTokens:
                parsed.usage?.completion_tokens ?? finalUsage.completionTokens,
              totalTokens: parsed.usage?.total_tokens ?? finalUsage.totalTokens
            };
          }

          const deltaText = choice?.delta?.content;
          if (typeof deltaText === 'string' && deltaText.length > 0) {
            yield {
              type: 'delta',
              content: deltaText
            };
          }
        }
      }
    }

    // In case stream ended unexpectedly without [DONE]
    yield {
      type: 'done',
      usage: finalUsage
    };
  }
}
