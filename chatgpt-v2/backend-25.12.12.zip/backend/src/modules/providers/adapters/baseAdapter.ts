// backend/src/modules/providers/adapters/baseAdapter.ts

import { ChatRequest, ChatResponse, ChatStreamChunk } from "../provider.types";

export interface ProviderAdapter {
  /**
   * Standard non-streaming completion.
   */
  sendChat(req: ChatRequest): Promise<ChatResponse>;

  /**
   * Optional streaming completion. If not implemented,
   * the caller can wrap `sendChat` as a single-chunk stream.
   */
  sendChatStream?(
    req: ChatRequest
  ): AsyncGenerator<ChatStreamChunk, void, unknown>;
}
