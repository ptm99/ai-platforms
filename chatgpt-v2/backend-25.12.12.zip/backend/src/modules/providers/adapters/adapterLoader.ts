// src/modules/providers/adapters/adapterLoader.ts

import path from 'path';
import { fileURLToPath } from 'url';
import { pool } from '../../../db/pool';
import { AIProvider } from '../provider.types';
import { ProviderAdapter } from './baseAdapter';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const adapters: Record<string, ProviderAdapter> = {};

/**
 * Load adapters dynamically from ai_providers.adapter_file.
 * adapter_file is e.g. "openai.adapter", "gemini.adapter", etc.
 */
export async function loadAdapters(): Promise<void> {
  console.log('[AdapterLoader] Loading provider adapters from database...');

  const res = await pool.query<AIProvider>(
    `
    SELECT *
    FROM ai_providers
    WHERE is_enabled = TRUE
    `
  );

  const encryptionKey = process.env.API_KEY_ENCRYPTION_SECRET || '';

  for (const provider of res.rows) {
    const modulePath = path.join(__dirname, provider.adapter_file);
    try {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const module = await import(modulePath);
      const exportedNames = Object.keys(module);
      if (exportedNames.length === 0) {
        console.warn(
          `[AdapterLoader] No exports found in adapter file for provider: ${provider.code} (${provider.adapter_file})`
        );
        continue;
      }

      const adapterClass = module[exportedNames[0]];
      adapters[provider.code] = new adapterClass(encryptionKey);

      console.log(
        `[AdapterLoader] Loaded adapter for provider: ${provider.code} (${provider.display_name})`
      );
    } catch (err: any) {
      console.error(
        `[AdapterLoader] FAILED to load adapter for provider: ${provider.code} (${provider.adapter_file}) – ${err.message}`
      );
    }
  }
}

/**
 * Get adapter instance by provider code (e.g. "openai", "gemini").
 */
export function getAdapter(providerCode: string): ProviderAdapter | undefined {
  return adapters[providerCode];
}
