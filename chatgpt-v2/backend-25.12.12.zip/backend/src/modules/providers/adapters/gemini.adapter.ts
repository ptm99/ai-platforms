import { ProviderAdapter } from "./baseAdapter";
import {
  ChatRequest,
  ChatResponse,
  ChatStreamChunk
} from "../provider.types";
import { decrypt } from "../../../utils/crypto";
import { fetchJson } from "./httpClient";

export class GeminiAdapter implements ProviderAdapter {
  constructor(private encryptionKey: string) {}

  async sendChat(req: ChatRequest): Promise<ChatResponse> {
    const apiKey = decrypt(req.providerKey.api_key_enc);

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${req.model}:generateContent?key=${apiKey}`;

    const body = {
      contents: req.messages.map((m) => ({
        role: m.role,
        parts: [{ text: m.content }]
      }))
    };

    const json = await fetchJson(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });

    const text =
      json?.candidates?.[0]?.content?.parts?.[0]?.text ??
      json.outputText ??
      "";

    return {
      content: text,
      promptTokens: json.usageMetadata?.promptTokenCount ?? 0,
      completionTokens: json.usageMetadata?.candidatesTokenCount ?? 0,
      totalTokens: json.usageMetadata?.totalTokenCount ?? 0
    };
  }

  async *sendChatStream(
    req: ChatRequest
  ): AsyncGenerator<ChatStreamChunk, void, unknown> {
    const full = await this.sendChat(req);

    yield {
      type: "delta",
      content: full.content
    };

    yield {
      type: "done",
      usage: {
        promptTokens: full.promptTokens,
        completionTokens: full.completionTokens,
        totalTokens: full.totalTokens
      }
    };
  }
}
