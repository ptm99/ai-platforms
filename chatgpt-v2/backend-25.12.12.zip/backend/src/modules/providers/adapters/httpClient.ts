// backend/src/modules/providers/adapters/httpClient.ts

import fetch from "node-fetch";

export async function fetchJson(url: string, opts: any): Promise<any> {
  const res = await fetch(url, opts);

  const text = await res.text();
  let json: any = null;

  try {
    json = JSON.parse(text);
  } catch {
    // text is not JSON
  }

  if (!res.ok) {
    throw new Error(
      `Request failed (${res.status}): ${json?.error ?? text ?? "Unknown error"}`
    );
  }

  return json;
}
