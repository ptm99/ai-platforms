// src/modules/providers/modelDiscovery.service.ts

import fetch from 'node-fetch';
import { pool } from '../../db/pool';
import { decrypt } from '../../utils/crypto';
import { AIProvider } from './provider.types';

async function getOneKeyForProvider(providerId: string): Promise<string | null> {
  const res = await pool.query(
    `
    SELECT api_key_enc
    FROM ai_provider_keys
    WHERE provider_id = $1
    ORDER BY created_at ASC
    LIMIT 1
    `,
    [providerId]
  );
  if (!res.rows.length) return null;
  return decrypt(res.rows[0].api_key_enc);
}

/**
 * Upsert model into ai_provider_models
 */
async function upsertModel(providerId: string, modelName: string, contextLength?: number) {
  await pool.query(
    `
    INSERT INTO ai_provider_models (provider_id, model_name, context_length, is_enabled)
    VALUES ($1, $2, $3, TRUE)
    ON CONFLICT (provider_id, model_name)
    DO UPDATE SET
       context_length = COALESCE(EXCLUDED.context_length, ai_provider_models.context_length),
       is_enabled = TRUE
    `,
    [providerId, modelName, contextLength ?? null]
  );
}

/* Provider-specific discovery helpers */

async function discoverOpenAIModels(provider: AIProvider, apiKey: string) {
  const resp = await fetch('https://api.openai.com/v1/models', {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${apiKey}`
    }
  });

  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`OpenAI model discovery failed: ${resp.status} ${text}`);
  }

  const data = await resp.json();
  for (const m of data.data ?? []) {
    const name = m.id as string;
    if (name.startsWith('gpt') || name.includes('o3')) {
      await upsertModel(provider.id, name, undefined);
    }
  }
}

async function discoverGeminiModels(provider: AIProvider, apiKey: string) {
  const resp = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`
  );
  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`Gemini model discovery failed: ${resp.status} ${text}`);
  }
  const data = await resp.json();
  for (const m of data.models ?? []) {
    const name = m.name?.split('/').pop();
    if (!name) continue;
    if (name.startsWith('gemini')) {
      await upsertModel(provider.id, name, m.inputTokenLimit ?? undefined);
    }
  }
}

async function discoverClaudeModels(provider: AIProvider) {
  const known = ['claude-3-haiku', 'claude-3-opus', 'claude-3-5-sonnet'];
  for (const name of known) {
    await upsertModel(provider.id, name, undefined);
  }
}

async function discoverDeepSeekModels(provider: AIProvider) {
  const known = ['deepseek-chat', 'deepseek-reasoner'];
  for (const name of known) {
    await upsertModel(provider.id, name, undefined);
  }
}

/**
 * Main entrypoint for startup/cron.
 */
export async function runAdapterAutodiscovery(): Promise<void> {
  console.log('[ModelDiscovery] Syncing provider models...');

  const providersRes = await pool.query<AIProvider>(
    `
    SELECT *
    FROM ai_providers
    WHERE is_enabled = TRUE
    `
  );

  for (const p of providersRes.rows) {
    try {
      const apiKey = await getOneKeyForProvider(p.id);

      if (!apiKey && p.code !== 'claude' && p.code !== 'deepseek') {
        console.warn(
          `[ModelDiscovery] No key available for provider ${p.code}, skipping`
        );
        continue;
      }

      if (p.code === 'openai') {
        await discoverOpenAIModels(p, apiKey!);
      } else if (p.code === 'gemini') {
        await discoverGeminiModels(p, apiKey!);
      } else if (p.code === 'claude') {
        await discoverClaudeModels(p);
      } else if (p.code === 'deepseek') {
        await discoverDeepSeekModels(p);
      } else {
        console.log(
          `[ModelDiscovery] No discovery logic implemented for provider ${p.code}, skipping`
        );
      }
    } catch (err: any) {
      console.error(
        `[ModelDiscovery] Error syncing models for provider ${p.code}: ${err.message}`
      );
    }
  }

  console.log('[ModelDiscovery] Done syncing provider models.');
}
