import { pool } from '../../db/pool';

export async function listUsers() {
  const res = await pool.query(
    `SELECT id, email, name, role, created_at, last_login_at
     FROM users
     ORDER BY created_at ASC`
  );
  return res.rows;
}

export async function updateUserRole(
  currentUserId: string,
  targetUserId: string,
  newRole: 'admin' | 'user' | 'superadmin'
) {
  // enforce: only super_admin can set roles; cannot demote last super_admin, etc.
  const current = await pool.query('SELECT id, role FROM users WHERE id = $1', [currentUserId]);
  if (!current.rows.length) throw new Error('Current user not found');
  if (current.rows[0].role !== 'superadmin') {
    if (newRole === 'superadmin') {
      throw new Error('Only superadmin can grant superadmin role');
    }
  }

  if (currentUserId === targetUserId && newRole !== 'superadmin') {
    // optional rule: prevent super_admin from accidentally demoting self
    // you can relax this if you want
  }

  const res = await pool.query(
    `UPDATE users
     SET role = $2
     WHERE id = $1
     RETURNING id, email, name, role, created_at`,
    [targetUserId, newRole]
  );
  if (!res.rows.length) {
    throw new Error('Target user not found');
  }
  return res.rows[0];
}
