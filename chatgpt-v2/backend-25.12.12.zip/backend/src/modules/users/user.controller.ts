import { Router, Request, Response } from 'express';
import { authRequired } from '../../middleware/auth.middleware';
import { requireRole } from '../../middleware/role.middleware';
import { listUsers, updateUserRole } from './user.service';

export const userAdminRouter = Router();

userAdminRouter.use(authRequired);
userAdminRouter.use(requireRole('admin')); // admin and super_admin

// GET /admin/users
userAdminRouter.get('/admin/users', async (_req: Request, res: Response) => {
  try {
    const users = await listUsers();
    res.json(users);
  } catch {
    res.status(500).json({ error: 'Failed to list users' });
  }
});

// PATCH /admin/users/:id/role
userAdminRouter.patch(
  '/admin/users/:id/role',
  requireRole('superadmin'), // only super_admin can change roles
  async (req: Request, res: Response) => {
    try {
      const currentUserId = req.user!.id;
      const targetUserId = req.params.id;
      const { role } = req.body;
      if (!role) return res.status(400).json({ error: 'role is required' });

      const user = await updateUserRole(currentUserId, targetUserId, role);
      res.json(user);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to update role' });
    }
  }
);
