// src/modules/projects/project.service.ts

import { pool } from '../../db/pool';
import { selectKeyForModel } from '../providers/keySelector.service';
import { getProviderById, getModelById } from '../providers/provider.service';

export type Visibility = 'private' | 'shared' | 'public';
export type MemberPermission = 'read' | 'edit';

export interface CreateProjectInput {
  ownerId: string;
  title: string;
  providerId: string;
  modelId: string;
}

export interface ProjectRecord {
  id: string;
  owner_id: string;
  title: string;
  visibility: Visibility;
  provider_id: string;
  model_id: string;
  provider_key_id: string;
  created_at: string;
  updated_at: string;
}

export interface ProjectMemberView {
  user_id: string;
  email: string;
  display_name: string | null;
  role: 'owner' | 'member';
  permission: MemberPermission | null;
  added_at: string | null;
}

/* ============================================================
 * Core Helpers
 * ============================================================ */

export async function getProjectById(projectId: string): Promise<ProjectRecord | null> {
  const res = await pool.query(
    `SELECT * FROM projects WHERE id = $1`,
    [projectId]
  );
  return res.rows[0] ?? null;
}

export async function countProjectMembers(projectId: string): Promise<number> {
  const res = await pool.query(
    `SELECT COUNT(*)::int AS count FROM project_members WHERE project_id = $1`,
    [projectId]
  );
  return res.rows[0]?.count ?? 0;
}

export async function findUserByEmail(email: string) {
  const res = await pool.query(
    `SELECT id, email, display_name FROM users WHERE email = $1`,
    [email.toLowerCase()]
  );
  if (!res.rows.length) return null;
  return {
    id: String(res.rows[0].id),
    email: res.rows[0].email,
    display_name: res.rows[0].display_name
  };
}

export async function isUserMember(projectId: string, userId: string) {
  const res = await pool.query(
    `SELECT 1 FROM project_members WHERE project_id = $1 AND user_id = $2`,
    [projectId, userId]
  );
  return res.rows.length > 0;
}

export async function userIsProjectOwner(userId: string, projectId: string): Promise<boolean> {
  const res = await pool.query(
    `SELECT 1 FROM projects WHERE id = $1 AND owner_id = $2`,
    [projectId, userId]
  );
  return res.rows.length > 0;
}

/* ============================================================
 * Access Control
 * ============================================================ */

export async function userCanReadProject(userId: string, projectId: string) {
  const res = await pool.query(
    `
    SELECT 1
    FROM projects p
    LEFT JOIN project_members pm
      ON pm.project_id = p.id AND pm.user_id = $1
    WHERE p.id = $2
      AND (
        p.owner_id = $1
        OR pm.user_id = $1
        OR p.visibility = 'public'
      )
    LIMIT 1
    `,
    [userId, projectId]
  );
  return res.rows.length > 0;
}

export async function userCanEditProject(userId: string, projectId: string) {
  const res = await pool.query(
    `
    SELECT 1
    FROM projects p
    LEFT JOIN project_members pm
      ON pm.project_id = p.id AND pm.user_id = $1 AND pm.permission = 'edit'
    WHERE p.id = $2
      AND (p.owner_id = $1 OR pm.user_id = $1)
    LIMIT 1
    `,
    [userId, projectId]
  );
  return res.rows.length > 0;
}

/* ============================================================
 * Project Creation
 * ============================================================ */

export async function createProject(input: CreateProjectInput): Promise<ProjectRecord> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const provider = await getProviderById(input.providerId);
    if (!provider || !provider.is_enabled) throw new Error('Provider disabled or missing');

    const model = await getModelById(input.modelId);
    if (!model || !model.is_enabled || model.provider_id !== provider.id)
      throw new Error('Model disabled or mismatched provider');

    const key = await selectKeyForModel(model.id);
    if (!key) throw new Error('No available key for model');

    const res = await client.query(
      `
      INSERT INTO projects (owner_id, title, visibility, provider_id, model_id, provider_key_id)
      VALUES ($1, $2, 'private', $3, $4, $5)
      RETURNING *
      `,
      [input.ownerId, input.title, provider.id, model.id, key.id]
    );

    await client.query('COMMIT');
    return res.rows[0];
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/* ============================================================
 * Members
 * ============================================================ */

export async function listProjectMembers(projectId: string): Promise<ProjectMemberView[]> {
  const res = await pool.query(
    `
    WITH owner AS (
      SELECT u.id AS user_id, u.email, u.display_name,
             'owner' AS role, NULL AS permission,
             p.created_at AS added_at
      FROM projects p
      JOIN users u ON u.id = p.owner_id
      WHERE p.id = $1
    ),
    members AS (
      SELECT u.id AS user_id, u.email, u.display_name,
             'member' AS role, pm.permission,
             pm.created_at AS added_at
      FROM project_members pm
      JOIN users u ON u.id = pm.user_id
      WHERE pm.project_id = $1
    )
    SELECT * FROM owner
    UNION ALL
    SELECT * FROM members
    ORDER BY role DESC, added_at
    `,
    [projectId]
  );

  return res.rows.map((r) => ({
    user_id: String(r.user_id),
    email: r.email,
    display_name: r.display_name,
    role: r.role,
    permission: r.permission,
    added_at: r.added_at
  }));
}

export async function addOrUpdateProjectMember(
  projectId: string,
  targetUserId: string,
  permission: MemberPermission
) {
  // Validate permission
  if (!['read', 'edit'].includes(permission)) {
    throw new Error('Invalid permission');
  }

  await pool.query(
    `
    INSERT INTO project_members (project_id, user_id, permission)
    VALUES ($1, $2, $3)
    ON CONFLICT (project_id, user_id)
    DO UPDATE SET permission = EXCLUDED.permission
    `,
    [projectId, targetUserId, permission]
  );
}

export async function removeProjectMember(projectId: string, targetUserId: string) {
  await pool.query(
    `
    DELETE FROM project_members
    WHERE project_id = $1 AND user_id = $2
    `,
    [projectId, targetUserId]
  );
}

/* ============================================================
 * Visibility Rules
 * ============================================================ */

export async function updateProjectVisibility(
  projectId: string,
  visibility: Visibility
): Promise<ProjectRecord> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const project = await getProjectById(projectId);
    if (!project) throw new Error('Project not found');

    const memberCount = await countProjectMembers(projectId);

    if (visibility === 'shared' && memberCount === 0) {
      throw new Error('Cannot set visibility to shared without collaborators');
    }

    if (visibility === 'private') {
      // Remove all collaborators
      await client.query(
        `DELETE FROM project_members WHERE project_id = $1`,
        [projectId]
      );
    }

    const res = await client.query(
      `
      UPDATE projects
      SET visibility = $2, updated_at = NOW()
      WHERE id = $1
      RETURNING *
      `,
      [projectId, visibility]
    );

    await client.query('COMMIT');
    return res.rows[0];
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/* ============================================================
 * Leave project
 * ============================================================ */

export async function leaveProject(projectId: string, userId: string) {
  const project = await getProjectById(projectId);
  if (!project) throw new Error('Project not found');

  if (String(project.owner_id) === String(userId)) {
    throw new Error('Owner cannot leave their own project');
  }

  const isMember = await isUserMember(projectId, userId);
  if (!isMember) throw new Error('User is not a collaborator');

  await removeProjectMember(projectId, userId);
}

/* ============================================================
 * Clone project (with messages)
 * ============================================================ */

export async function cloneProject(sourceId: string, newOwnerId: string) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const srcRes = await client.query(`SELECT * FROM projects WHERE id = $1`, [sourceId]);
    if (!srcRes.rows.length) throw new Error('Source project not found');
    const src = srcRes.rows[0] as ProjectRecord;

    const newRes = await client.query(
      `
      INSERT INTO projects (owner_id, title, visibility, provider_id, model_id, provider_key_id)
      VALUES ($1, $2 || ' (Copy)', 'private', $3, $4, $5)
      RETURNING *
      `,
      [newOwnerId, src.title, src.provider_id, src.model_id, src.provider_key_id]
    );

    const newProject = newRes.rows[0] as ProjectRecord;

    await client.query(
      `
      INSERT INTO messages (project_id, user_id, role, content, provider_code, model_name, created_at)
      SELECT $2, user_id, role, content, provider_code, model_name, created_at
      FROM messages
      WHERE project_id = $1
      `,
      [sourceId, newProject.id]
    );

    await client.query('COMMIT');
    return newProject;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}
