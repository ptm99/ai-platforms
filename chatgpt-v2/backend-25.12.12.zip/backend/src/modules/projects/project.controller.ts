// src/modules/projects/project.controller.ts
import { Router, RequestHandler } from 'express';
import { authRequired } from '../../middleware/auth.middleware';
import * as ProjectService from './project.service';

export const projectRouter = Router();
projectRouter.use(authRequired);

const listProjects: RequestHandler = async (req, res) => {
  res.json(await ProjectService.listUserProjects(req.user!.id));
};

projectRouter.get('/', listProjects);

/* ============================================================
 * POST /projects
 * ============================================================ */
projectRouter.post('/', async (req: AuthReq, res) => {
  const { title, provider_id, model_id } = req.body;
  if (!title || !provider_id || !model_id)
    return res.status(400).json({ error: 'Missing required fields' });

  try {
    const project = await createProject({
      ownerId: req.user.id,
      title,
      providerId: provider_id,
      modelId: model_id
    });
    res.status(201).json(project);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

/* ============================================================
 * GET /projects/:id
 * ============================================================ */
projectRouter.get('/:id', async (req: AuthReq, res) => {
  const projectId = req.params.id;
  try {
    const canRead = await userCanReadProject(req.user.id, projectId);
    if (!canRead) return res.status(403).json({ error: 'Forbidden' });

    const project = await getProjectById(projectId);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    res.json(project);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/* ============================================================
 * GET /projects/:id/members
 * ============================================================ */
projectRouter.get('/:id/members', async (req: AuthReq, res) => {
  const projectId = req.params.id;
  try {
    const canRead = await userCanReadProject(req.user.id, projectId);
    if (!canRead) return res.status(403).json({ error: 'Forbidden' });

    const members = await listProjectMembers(projectId);
    res.json(members);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/* ============================================================
 * POST /projects/:id/members
 * ============================================================ */
projectRouter.post('/:id/members', async (req: AuthReq, res) => {
  const projectId = req.params.id;
  const { email, permission } = req.body;

  if (!email || !['read', 'edit'].includes(permission))
    return res.status(400).json({
      error: 'Email and permission ("read" | "edit") required'
    });

  try {
    const isOwner = await userIsProjectOwner(req.user.id, projectId);
    const isAdmin = ['admin', 'superadmin'].includes(req.user.role);
    if (!isOwner && !isAdmin)
      return res.status(403).json({ error: 'Not allowed' });

    const project = await getProjectById(projectId);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    const target = await findUserByEmail(email);
    if (!target) return res.status(404).json({ error: 'User not found' });

    if (target.id === req.user.id)
      return res.status(400).json({ error: 'Cannot add yourself' });

    if (String(project.owner_id) === target.id)
      return res.status(400).json({ error: 'Owner cannot be a member' });

    if (project.visibility === 'public')
      return res.status(400).json({
        error: 'Public projects do not require collaborators'
      });

    await addOrUpdateProjectMember(projectId, target.id, permission);
    const members = await listProjectMembers(projectId);
    res.status(201).json(members);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

/* ============================================================
 * PATCH /projects/:id/members/:userId
 * ============================================================ */
projectRouter.patch('/:id/members/:userId', async (req: AuthReq, res) => {
  const projectId = req.params.id;
  const targetId = req.params.userId;
  const { permission } = req.body as { permission: MemberPermission };

  if (!['read', 'edit'].includes(permission))
    return res.status(400).json({ error: 'Invalid permission' });

  try {
    const isOwner = await userIsProjectOwner(req.user.id, projectId);
    const isAdmin = ['admin', 'superadmin'].includes(req.user.role);
    if (!isOwner && !isAdmin) return res.status(403).json({ error: 'Forbidden' });

    const project = await getProjectById(projectId);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    if (String(project.owner_id) === targetId)
      return res.status(400).json({ error: 'Cannot modify owner' });

    const exists = await isUserMember(projectId, targetId);
    if (!exists) return res.status(404).json({ error: 'Member not found' });

    await addOrUpdateProjectMember(projectId, targetId, permission);
    const members = await listProjectMembers(projectId);
    res.json(members);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

/* ============================================================
 * DELETE /projects/:id/members/:userId
 * ============================================================ */
projectRouter.delete('/:id/members/:userId', async (req: AuthReq, res) => {
  const projectId = req.params.id;
  const targetId = req.params.userId;

  try {
    const isOwner = await userIsProjectOwner(req.user.id, projectId);
    const isAdmin = ['admin', 'superadmin'].includes(req.user.role);
    if (!isOwner && !isAdmin)
      return res.status(403).json({ error: 'Forbidden' });

    const project = await getProjectById(projectId);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    if (String(project.owner_id) === targetId)
      return res.status(400).json({ error: 'Cannot remove owner' });

    const exists = await isUserMember(projectId, targetId);
    if (!exists) return res.status(404).json({ error: 'Member not found' });

    await removeProjectMember(projectId, targetId);
    const members = await listProjectMembers(projectId);
    res.json(members);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

/* ============================================================
 * DELETE /projects/:id/members/me
 * ============================================================ */
projectRouter.delete('/:id/members/me', async (req: AuthReq, res) => {
  const projectId = req.params.id;

  try {
    await leaveProject(projectId, req.user.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

/* ============================================================
 * PATCH /projects/:id/visibility
 * ============================================================ */
projectRouter.patch('/:id/visibility', async (req: AuthReq, res) => {
  const projectId = req.params.id;
  const { visibility } = req.body as { visibility: Visibility };

  if (!['private', 'shared', 'public'].includes(visibility))
    return res.status(400).json({ error: 'Invalid visibility' });

  try {
    const isOwner = await userIsProjectOwner(req.user.id, projectId);
    const isAdmin = ['admin', 'superadmin'].includes(req.user.role);
    if (!isOwner && !isAdmin)
      return res.status(403).json({ error: 'Forbidden' });

    const project = await getProjectById(projectId);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    if (visibility === 'shared') {
      const count = await countProjectMembers(projectId);
      if (count === 0) {
        return res.status(400).json({
          error: 'Cannot set shared visibility without collaborators'
        });
      }
    }

    // If private → clear members handled by service
    const updated = await updateProjectVisibility(projectId, visibility);
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

/* ============================================================
 * POST /projects/:id/clone
 * ============================================================ */
projectRouter.post('/:id/clone', async (req: AuthReq, res) => {
  const projectId = req.params.id;

  try {
    const canRead = await userCanReadProject(req.user.id, projectId);
    if (!canRead) return res.status(403).json({ error: 'Forbidden' });

    const newProject = await cloneProject(projectId, req.user.id);
    res.status(201).json(newProject);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});
