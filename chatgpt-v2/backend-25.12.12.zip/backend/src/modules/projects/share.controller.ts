import { Router, Request, Response } from 'express';
import { authRequired } from '../../middleware/auth.middleware';
import { pool } from '../../db/pool';
import { userCanEditProject } from './project.service';

export const shareRouter = Router();

shareRouter.use(authRequired);

// GET /projects/:id/shares
shareRouter.get('/projects/:id/shares', async (req: Request, res: Response) => {
  try {
    const projectId = req.params.id;
    const canEdit = await userCanEditProject(req.user!.id, projectId);
    if (!canEdit) return res.status(403).json({ error: 'Forbidden' });

    const result = await pool.query(
      `
      SELECT pm.id, pm.user_id, u.email, u.name, pm.permission, pm.created_at
      FROM project_members pm
      JOIN users u ON u.id = pm.user_id
      WHERE pm.project_id = $1
      `,
      [projectId]
    );
    res.json(result.rows);
  } catch {
    res.status(500).json({ error: 'Failed to list shares' });
  }
});

// POST /projects/:id/shares
shareRouter.post('/projects/:id/shares', async (req: Request, res: Response) => {
  try {
    const projectId = req.params.id;
    const { user_id, permission } = req.body;
    if (!user_id || !permission) {
      return res.status(400).json({ error: 'user_id and permission are required' });
    }

    const canEdit = await userCanEditProject(req.user!.id, projectId);
    if (!canEdit) return res.status(403).json({ error: 'Forbidden' });

    const insert = await pool.query(
      `
      INSERT INTO project_members (project_id, user_id, permission, added_by)
      VALUES ($1, $2, $3, $4)
      ON CONFLICT (project_id, user_id)
      DO UPDATE SET permission = EXCLUDED.permission
      RETURNING *
      `,
      [projectId, user_id, permission, req.user!.id]
    );
    res.status(201).json(insert.rows[0]);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to share project' });
  }
});

// DELETE /projects/:projectId/shares/:shareId
shareRouter.delete(
  '/projects/:projectId/shares/:shareId',
  async (req: Request, res: Response) => {
    try {
      const projectId = req.params.projectId;
      const shareId = req.params.shareId;

      const canEdit = await userCanEditProject(req.user!.id, projectId);
      if (!canEdit) return res.status(403).json({ error: 'Forbidden' });

      await pool.query(
        `DELETE FROM project_members WHERE id = $1 AND project_id = $2`,
        [shareId, projectId]
      );
      res.status(204).send();
    } catch {
      res.status(400).json({ error: 'Failed to remove share' });
    }
  }
);
