// src/modules/admin/admin.router.ts

import { Router } from 'express';
import { authRequired, requireRole } from '../../middleware/auth.middleware';
import { adminProvidersRouter } from './providers.admin.controller';
import { adminModelsRouter } from './models.admin.controller';
import { adminKeysRouter } from './keys.admin.controller';

export const adminRouter = Router();

// all /admin routes require login + admin role
adminRouter.use(authRequired);
adminRouter.use(requireRole('admin'));

adminRouter.use('/providers', adminProvidersRouter);
adminRouter.use('/models', adminModelsRouter);
adminRouter.use('/keys', adminKeysRouter);
