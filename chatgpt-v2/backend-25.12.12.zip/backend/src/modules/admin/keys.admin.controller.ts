// src/modules/admin/keys.admin.controller.ts

import { Router, Request, Response } from 'express';
import {
  adminCreateKey,
  adminDeleteKey,
  adminListKeys,
  adminUpdateKey
} from './keys.admin.service';

export const adminKeysRouter = Router();

adminKeysRouter.get('/', async (req: Request, res: Response) => {
  const modelId = typeof req.query.model_id === 'string' ? req.query.model_id : undefined;
  try {
    const rows = await adminListKeys(modelId);
    res.json(rows);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to list keys' });
  }
});

adminKeysRouter.post('/', async (req: Request, res: Response) => {
  const { provider_id, model_id, name, api_key_plain, daily_limit } = req.body || {};
  if (!provider_id || !model_id || !api_key_plain) {
    return res.status(400).json({ error: 'provider_id, model_id, api_key_plain are required' });
  }

  const limit =
    typeof daily_limit === 'number'
      ? daily_limit
      : typeof daily_limit === 'string' && daily_limit.trim()
        ? parseInt(daily_limit, 10)
        : undefined;

  try {
    const row = await adminCreateKey({
      provider_id: String(provider_id),
      model_id: String(model_id),
      name: typeof name === 'string' ? name : undefined,
      api_key_plain: String(api_key_plain),
      daily_limit: typeof limit === 'number' && Number.isFinite(limit) ? limit : undefined
    });
    res.status(201).json(row);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to create key' });
  }
});

adminKeysRouter.patch('/:id', async (req: Request, res: Response) => {
  const keyId = req.params.id;
  const { status, daily_limit } = req.body || {};

  if (typeof status === 'undefined' && typeof daily_limit === 'undefined') {
    return res.status(400).json({ error: 'No fields provided to update' });
  }

  const limit =
    typeof daily_limit === 'number'
      ? daily_limit
      : typeof daily_limit === 'string' && daily_limit.trim()
        ? parseInt(daily_limit, 10)
        : undefined;

  try {
    const row = await adminUpdateKey(keyId, {
      status: typeof status === 'string' ? status : undefined,
      daily_limit: typeof limit === 'number' && Number.isFinite(limit) ? limit : undefined
    });
    if (!row) return res.status(404).json({ error: 'Key not found' });
    res.json(row);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to update key' });
  }
});

adminKeysRouter.delete('/:id', async (req: Request, res: Response) => {
  const keyId = req.params.id;
  try {
    await adminDeleteKey(keyId);
    res.json({ success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to delete key' });
  }
});
