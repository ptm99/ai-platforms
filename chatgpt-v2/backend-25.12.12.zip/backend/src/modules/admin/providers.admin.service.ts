// src/modules/admin/providers.admin.service.ts

import { pool } from '../../db/pool';

export async function adminListProviders() {
  const res = await pool.query(
    `SELECT * FROM ai_providers ORDER BY created_at DESC`
  );
  return res.rows;
}

export async function adminCreateProvider(input: {
  code: string;
  display_name: string;
  adapter_file: string;
  description?: string;
}) {
  const res = await pool.query(
    `
    INSERT INTO ai_providers (code, display_name, adapter_file, description)
    VALUES ($1, $2, $3, $4)
    RETURNING *
    `,
    [input.code, input.display_name, input.adapter_file, input.description ?? null]
  );
  return res.rows[0];
}

export async function adminUpdateProvider(
  providerId: string,
  patch: {
    is_enabled?: boolean;
    display_name?: string;
    adapter_file?: string;
    description?: string;
  }
) {
  const fields: string[] = [];
  const values: any[] = [];
  let idx = 1;

  if (typeof patch.is_enabled === 'boolean') {
    fields.push(`is_enabled = $${idx++}`);
    values.push(patch.is_enabled);
  }
  if (typeof patch.display_name === 'string') {
    fields.push(`display_name = $${idx++}`);
    values.push(patch.display_name);
  }
  if (typeof patch.adapter_file === 'string') {
    fields.push(`adapter_file = $${idx++}`);
    values.push(patch.adapter_file);
  }
  if (typeof patch.description === 'string') {
    fields.push(`description = $${idx++}`);
    values.push(patch.description);
  }

  if (!fields.length) {
    throw new Error('No fields to update');
  }

  values.push(providerId);

  const res = await pool.query(
    `
    UPDATE ai_providers
    SET ${fields.join(', ')}, updated_at = NOW()
    WHERE id = $${idx}
    RETURNING *
    `,
    values
  );

  return res.rows[0] ?? null;
}

export async function adminDeleteProvider(providerId: string) {
  // This cascades to models/keys via FK ON DELETE CASCADE.
  await pool.query(`DELETE FROM ai_providers WHERE id = $1`, [providerId]);
}
