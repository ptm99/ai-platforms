// src/modules/admin/models.admin.controller.ts

import { Router, Request, Response } from 'express';
import {
  adminCreateModel,
  adminDeleteModel,
  adminListModels,
  adminUpdateModel
} from './models.admin.service';

export const adminModelsRouter = Router();

adminModelsRouter.get('/', async (req: Request, res: Response) => {
  const providerId = typeof req.query.provider_id === 'string' ? req.query.provider_id : undefined;
  try {
    const rows = await adminListModels(providerId);
    res.json(rows);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to list models' });
  }
});

adminModelsRouter.post('/', async (req: Request, res: Response) => {
  const { provider_id, model_name, context_length } = req.body || {};
  if (!provider_id || !model_name) {
    return res.status(400).json({ error: 'provider_id and model_name are required' });
  }

  const ctx =
    typeof context_length === 'number'
      ? context_length
      : typeof context_length === 'string' && context_length.trim()
        ? parseInt(context_length, 10)
        : null;

  try {
    const row = await adminCreateModel({
      provider_id: String(provider_id),
      model_name: String(model_name).trim(),
      context_length: Number.isFinite(ctx as any) ? (ctx as number) : null
    });
    res.status(201).json(row);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to create model' });
  }
});

adminModelsRouter.patch('/:id', async (req: Request, res: Response) => {
  const modelId = req.params.id;
  const { is_enabled, context_length } = req.body || {};

  if (typeof is_enabled === 'undefined' && typeof context_length === 'undefined') {
    return res.status(400).json({ error: 'No fields provided to update' });
  }

  const ctx =
    typeof context_length === 'number'
      ? context_length
      : typeof context_length === 'string' && context_length.trim()
        ? parseInt(context_length, 10)
        : undefined;

  try {
    const row = await adminUpdateModel(modelId, {
      is_enabled: typeof is_enabled === 'boolean' ? is_enabled : undefined,
      context_length: typeof ctx === 'number' && Number.isFinite(ctx) ? ctx : undefined
    });
    if (!row) return res.status(404).json({ error: 'Model not found' });
    res.json(row);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to update model' });
  }
});

adminModelsRouter.delete('/:id', async (req: Request, res: Response) => {
  const modelId = req.params.id;
  try {
    await adminDeleteModel(modelId);
    res.json({ success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to delete model' });
  }
});
