// src/utils/jwt.util.ts

import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'change_me';
const ACCESS_TOKEN_TTL = process.env.ACCESS_TOKEN_TTL || '15m'; // e.g. "15m"
const REFRESH_TOKEN_TTL = process.env.REFRESH_TOKEN_TTL || '30d'; // e.g. "30d"

export interface AccessTokenPayload extends jwt.JwtPayload {
  sub: string;  // user id
  role: 'user' | 'admin' | 'superadmin';
  type: 'access';
}

export interface RefreshTokenPayload extends jwt.JwtPayload {
  sub: string;      // user id
  sid: string;      // session id
  type: 'refresh';
}

export function signAccessToken(user: {
  id: string | number;
  role: 'user' | 'admin' | 'superadmin';
}): string {
  const payload: AccessTokenPayload = {
    sub: String(user.id),
    role: user.role,
    type: 'access'
  };

  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: ACCESS_TOKEN_TTL
  });
}

export function signRefreshToken(userId: string | number, sessionId: string | number): string {
  const payload: RefreshTokenPayload = {
    sub: String(userId),
    sid: String(sessionId),
    type: 'refresh'
  };

  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: REFRESH_TOKEN_TTL
  });
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  const decoded = jwt.verify(token, JWT_SECRET) as jwt.JwtPayload;

  if (!decoded || decoded.type !== 'access') {
    throw new Error('Invalid access token type');
  }

  return decoded as AccessTokenPayload;
}

export function verifyRefreshToken(token: string): RefreshTokenPayload {
  const decoded = jwt.verify(token, JWT_SECRET) as jwt.JwtPayload;

  if (!decoded || decoded.type !== 'refresh') {
    throw new Error('Invalid refresh token type');
  }

  return decoded as RefreshTokenPayload;
}
