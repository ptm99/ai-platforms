-- =============================================================
--  ENUM TYPES
-- =============================================================

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
        CREATE TYPE user_role AS ENUM ('superadmin','admin','user');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'project_visibility') THEN
        CREATE TYPE project_visibility AS ENUM ('private','shared','public');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'project_permission') THEN
        CREATE TYPE project_permission AS ENUM ('read','edit');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'message_role') THEN
        CREATE TYPE message_role AS ENUM ('user','assistant','system');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'key_status') THEN
        CREATE TYPE key_status AS ENUM ('active','exhausted','disabled');
    END IF;
END $$;

-- Enable if not already present:
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
  id            BIGSERIAL PRIMARY KEY,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name  VARCHAR(255),
  role          VARCHAR(32) NOT NULL DEFAULT 'user', -- user | admin | superadmin
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- USER SESSIONS (REFRESH TOKENS)
CREATE TABLE IF NOT EXISTS user_sessions (
  id                 BIGSERIAL PRIMARY KEY,
  user_id            BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  refresh_token_hash TEXT NOT NULL,
  user_agent         TEXT,
  ip_address         TEXT,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at         TIMESTAMPTZ NOT NULL,
  revoked_at         TIMESTAMPTZ,
  last_refreshed_at  TIMESTAMPTZ
);



-- =============================================================
--  AI PROVIDERS (dynamic adapters)
-- =============================================================

CREATE TABLE IF NOT EXISTS ai_providers (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code          TEXT UNIQUE NOT NULL,            -- openai, claude, gemini, deepseek, newai
    display_name  TEXT NOT NULL,
    adapter_file  TEXT NOT NULL,                   -- openai.adapter / claude.adapter / etc.
    is_enabled    BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- =============================================================
--  AI PROVIDER MODELS (per-provider multiple models)
-- =============================================================

CREATE TABLE IF NOT EXISTS ai_provider_models (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider_id     UUID NOT NULL REFERENCES ai_providers(id) ON DELETE CASCADE,
    model_name      TEXT NOT NULL,                 -- e.g. gpt-4.2, gemini-pro, claude-3-haiku
    is_enabled      BOOLEAN NOT NULL DEFAULT TRUE,
    context_length  INTEGER,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(provider_id, model_name)
);


-- =============================================================
--  API KEYS (per model)
-- =============================================================

CREATE TABLE IF NOT EXISTS ai_provider_keys (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider_id     UUID NOT NULL REFERENCES ai_providers(id) ON DELETE CASCADE,
    model_id        UUID NOT NULL REFERENCES ai_provider_models(id) ON DELETE CASCADE,
    api_key_enc     TEXT NOT NULL,
    name            TEXT,
    status          key_status NOT NULL DEFAULT 'active',
    daily_limit     INTEGER NOT NULL,
    daily_usage     INTEGER NOT NULL DEFAULT 0,
    last_reset_at   DATE NOT NULL DEFAULT CURRENT_DATE,
    last_used_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- =============================================================
--  PROJECTS (bind provider + model + key)
-- =============================================================

CREATE TABLE IF NOT EXISTS projects (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title           TEXT NOT NULL,
    visibility      project_visibility NOT NULL DEFAULT 'private',
    provider_id     UUID NOT NULL REFERENCES ai_providers(id),
    model_id        UUID NOT NULL REFERENCES ai_provider_models(id),
    provider_key_id UUID NOT NULL REFERENCES ai_provider_keys(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- =============================================================
--  PROJECT SHARING
-- =============================================================

CREATE TABLE IF NOT EXISTS project_members (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id    UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    permission    project_permission NOT NULL DEFAULT 'read',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(project_id, user_id)
);


-- =============================================================
--  MESSAGES
-- =============================================================

CREATE TABLE IF NOT EXISTS messages (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id    UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id       UUID REFERENCES users(id) ON DELETE SET NULL,
    role          message_role NOT NULL,
    content       JSONB NOT NULL,
    provider_code TEXT,
    model_name    TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- =============================================================
--  USAGE LOGS
-- =============================================================

CREATE TABLE IF NOT EXISTS usage_logs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID REFERENCES users(id) ON DELETE SET NULL,
    project_id      UUID REFERENCES projects(id) ON DELETE CASCADE,
    provider_id     UUID REFERENCES ai_providers(id) ON DELETE SET NULL,
    model_id        UUID REFERENCES ai_provider_models(id) ON DELETE SET NULL,
    provider_key_id UUID REFERENCES ai_provider_keys(id) ON DELETE SET NULL,
    tokens_in       INTEGER NOT NULL,
    tokens_out      INTEGER NOT NULL,
    cost            NUMERIC(16,6),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- =============================================================
--  INDEXES
-- =============================================================

CREATE INDEX IF NOT EXISTS idx_users_email ON users (email);
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions (user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_expires_at ON user_sessions (expires_at);
CREATE INDEX IF NOT EXISTS idx_messages_project ON messages(project_id);
CREATE INDEX IF NOT EXISTS idx_usage_user ON usage_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_usage_project ON usage_logs(project_id);
CREATE INDEX IF NOT EXISTS idx_keys_provider ON ai_provider_keys(provider_id);
CREATE INDEX IF NOT EXISTS idx_models_provider ON ai_provider_models(provider_id);
