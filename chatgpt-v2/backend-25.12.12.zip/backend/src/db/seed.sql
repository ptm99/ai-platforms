--
-- SEED DATA FOR DEVELOP / DEMO ENVIRONMENTS
-- Safe defaults: no admin credentials unless you uncomment manually.
--

------------------------------------------------------------
-- Example: Insert demo users
------------------------------------------------------------

-- Insert demo superadmin (uncomment + replace hash as needed)
-- Password hash here is example only; replace with real bcrypt hash.
-- INSERT INTO users (email, password_hash, display_name, role)
-- VALUES ('admin@example.com', '$2a$10$abcdefghijklmnopqrstuv', 'Superadmin', 'superadmin')
-- ON CONFLICT (email) DO NOTHING;

-- Insert demo user
INSERT INTO users (email, password_hash, display_name, role)
VALUES ('user1@example.com', '$2a$10$abcdefghijklmnopqrstuv', 'User One', 'user')
ON CONFLICT (email) DO NOTHING;


------------------------------------------------------------
-- Providers (already inserted in init.sql but repeated here for completeness)
------------------------------------------------------------

INSERT INTO ai_providers (code, display_name, adapter_file, description)
VALUES
 ('openai',   'OpenAI',          'openai.adapter',   'OpenAI GPT Models'),
 ('gemini',   'Google Gemini',   'gemini.adapter',   'Gemini Models'),
 ('claude',   'Anthropic',       'claude.adapter',   'Claude Models'),
 ('deepseek', 'DeepSeek',        'deepseek.adapter', 'DeepSeek Models')
ON CONFLICT (code) DO NOTHING;


------------------------------------------------------------
-- MODELS FOR TESTING
-- (init.sql will populate models via autodiscovery, but you can pre-seed)
------------------------------------------------------------

-- OpenAI models
INSERT INTO ai_provider_models (provider_id, model_name, context_length)
SELECT p.id, 'gpt-4.1-mini', 128000
FROM ai_providers p WHERE p.code = 'openai'
ON CONFLICT DO NOTHING;

INSERT INTO ai_provider_models (provider_id, model_name, context_length)
SELECT p.id, 'gpt-4.1', 128000
FROM ai_providers p WHERE p.code = 'openai'
ON CONFLICT DO NOTHING;


-- Gemini models
INSERT INTO ai_provider_models (provider_id, model_name, context_length)
SELECT p.id, 'gemini-1.5-flash', 1000000
FROM ai_providers p WHERE p.code = 'gemini'
ON CONFLICT DO NOTHING;


-- Claude models
INSERT INTO ai_provider_models (provider_id, model_name, context_length)
SELECT p.id, 'claude-3-haiku', 200000
FROM ai_providers p WHERE p.code = 'claude'
ON CONFLICT DO NOTHING;


-- DeepSeek models
INSERT INTO ai_provider_models (provider_id, model_name, context_length)
SELECT p.id, 'deepseek-chat', 16000
FROM ai_providers p WHERE p.code = 'deepseek'
ON CONFLICT DO NOTHING;


------------------------------------------------------------
-- Insert API Keys (ENCRYPTED keys – replace with real encrypted strings)
------------------------------------------------------------

-- Example encrypted placeholder: "ENC(...)"
-- Replace these with encrypt(apiKey) output from your system.

-- OpenAI key for gpt-4.1-mini
INSERT INTO ai_provider_keys (provider_id, model_id, api_key_enc, name, daily_limit)
SELECT p.id, m.id, 'ENC(openai-key-example)', 'OpenAI Key #1', 200000
FROM ai_providers p
JOIN ai_provider_models m ON m.provider_id = p.id AND m.model_name = 'gpt-4.1-mini'
WHERE p.code = 'openai'
ON CONFLICT DO NOTHING;


-- Gemini key example
INSERT INTO ai_provider_keys (provider_id, model_id, api_key_enc, name, daily_limit)
SELECT p.id, m.id, 'ENC(gemini-key-example)', 'Gemini Key #1', 300000
FROM ai_providers p
JOIN ai_provider_models m ON m.provider_id = p.id AND m.model_name = 'gemini-1.5-flash'
WHERE p.code = 'gemini'
ON CONFLICT DO NOTHING;


------------------------------------------------------------
-- Insert Sample Project
------------------------------------------------------------

-- Create project for demo user
INSERT INTO projects (owner_id, title, visibility, provider_id, model_id, provider_key_id)
SELECT
  u.id,
  'Demo Project',
  'private',
  pm.provider_id,
  pm.id AS model_id,
  pk.id AS provider_key_id
FROM users u
JOIN ai_provider_models pm ON pm.model_name = 'gpt-4.1-mini'
JOIN ai_provider_keys pk ON pk.model_id = pm.id
WHERE u.email = 'user1@example.com'
LIMIT 1;


------------------------------------------------------------
-- Insert Sample Messages
------------------------------------------------------------

INSERT INTO messages (project_id, user_id, role, content, provider_code, model_name)
SELECT
  p.id,
  u.id,
  'user',
  '{"text": "Hello, AI!"}'::jsonb,
  'openai',
  'gpt-4.1-mini'
FROM projects p
JOIN users u ON u.email = 'user1@example.com'
LIMIT 1;


INSERT INTO messages (project_id, user_id, role, content, provider_code, model_name)
SELECT
  p.id,
  NULL,
  'assistant',
  '{"text": "Hello! How can I assist you?"}'::jsonb,
  'openai',
  'gpt-4.1-mini'
FROM projects p
LIMIT 1;


------------------------------------------------------------
-- Insert Example Usage Logs
------------------------------------------------------------

INSERT INTO usage_logs (
  user_id, project_id, provider_id, model_id, provider_key_id,
  tokens_in, tokens_out, cost
)
SELECT
  u.id,
  p.id,
  p.provider_id,
  p.model_id,
  p.provider_key_id,
  15, 50, 0.002
FROM users u
JOIN projects p ON p.owner_id = u.id
LIMIT 1;


-- INSERT INTO ai_providers (code, display_name, adapter_file)
-- VALUES ('newai', 'New AI Provider', 'newai.adapter');