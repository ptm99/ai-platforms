--
-- COMPLETE DATABASE INITIALIZATION SCRIPT (WITH CONSTRAINTS)
-- Multi-Tenant AI Platform
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

------------------------------------------------------------
-- ENUM-LIKE CHECK HELPERS (TEXT FIELDS)
------------------------------------------------------------

-- roles: user | admin | superadmin
-- visibility: private | shared | public
-- project member permission: read | edit
-- key status: active | exhausted | disabled

------------------------------------------------------------
-- USERS & AUTHENTICATION
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS users (
  id            BIGSERIAL PRIMARY KEY,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name  VARCHAR(255),
  role          VARCHAR(32) NOT NULL DEFAULT 'user',
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_users_role
    CHECK (role IN ('user','admin','superadmin'))
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);


------------------------------------------------------------
-- USER SESSIONS (DB-backed refresh tokens)
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS user_sessions (
  id                 BIGSERIAL PRIMARY KEY,
  user_id            BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  refresh_token_hash TEXT NOT NULL,
  user_agent         TEXT,
  ip_address         TEXT,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at         TIMESTAMPTZ NOT NULL,
  revoked_at         TIMESTAMPTZ,
  last_refreshed_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_expires_at ON user_sessions(expires_at);


------------------------------------------------------------
-- AI PROVIDERS
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ai_providers (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code         VARCHAR(50) NOT NULL UNIQUE,
  display_name VARCHAR(255) NOT NULL,
  adapter_file VARCHAR(255) NOT NULL,
  is_enabled   BOOLEAN NOT NULL DEFAULT TRUE,
  description  TEXT,
  logo_url     TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


------------------------------------------------------------
-- AI PROVIDER MODELS
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ai_provider_models (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  provider_id    UUID NOT NULL REFERENCES ai_providers(id) ON DELETE CASCADE,
  model_name     VARCHAR(255) NOT NULL,
  context_length INTEGER,
  is_enabled     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(provider_id, model_name)
);

CREATE INDEX IF NOT EXISTS idx_provider_models_provider_id ON ai_provider_models(provider_id);


------------------------------------------------------------
-- API KEYS PER PROVIDER MODEL
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ai_provider_keys (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  provider_id    UUID NOT NULL REFERENCES ai_providers(id) ON DELETE CASCADE,
  model_id       UUID NOT NULL REFERENCES ai_provider_models(id) ON DELETE CASCADE,
  api_key_enc    TEXT NOT NULL,
  name           VARCHAR(255),
  status         VARCHAR(20) NOT NULL DEFAULT 'active',
  daily_limit    INTEGER NOT NULL DEFAULT 1000000,
  daily_usage    INTEGER NOT NULL DEFAULT 0,
  last_reset_at  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_DATE,
  last_used_at   TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_keys_status
    CHECK (status IN ('active','exhausted','disabled')),
  CONSTRAINT chk_keys_daily_limit
    CHECK (daily_limit >= 0),
  CONSTRAINT chk_keys_daily_usage
    CHECK (daily_usage >= 0),
  UNIQUE(model_id, api_key_enc)
);

CREATE INDEX IF NOT EXISTS idx_provider_keys_model_id ON ai_provider_keys(model_id);
CREATE INDEX IF NOT EXISTS idx_provider_keys_provider_id ON ai_provider_keys(provider_id);


------------------------------------------------------------
-- PROJECTS
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS projects (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id        BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title           VARCHAR(255) NOT NULL,
  visibility      VARCHAR(20) NOT NULL DEFAULT 'private',
  provider_id     UUID NOT NULL REFERENCES ai_providers(id),
  model_id        UUID NOT NULL REFERENCES ai_provider_models(id),
  provider_key_id UUID NOT NULL REFERENCES ai_provider_keys(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_projects_visibility
    CHECK (visibility IN ('private','shared','public'))
);

CREATE INDEX IF NOT EXISTS idx_projects_owner_id ON projects(owner_id);


------------------------------------------------------------
-- PROJECT MEMBERS
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS project_members (
  id           BIGSERIAL PRIMARY KEY,
  project_id   UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  permission   VARCHAR(20) NOT NULL DEFAULT 'read',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_project_members_permission
    CHECK (permission IN ('read','edit')),
  CONSTRAINT uq_project_members UNIQUE (project_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_project_members_project_id ON project_members(project_id);


------------------------------------------------------------
-- MESSAGES
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS messages (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id    UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id       BIGINT REFERENCES users(id) ON DELETE SET NULL,
  role          VARCHAR(20) NOT NULL,
  content       JSONB NOT NULL,
  provider_code VARCHAR(50),
  model_name    VARCHAR(255),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_messages_role
    CHECK (role IN ('user','assistant','system'))
);

CREATE INDEX IF NOT EXISTS idx_messages_project_id ON messages(project_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);


------------------------------------------------------------
-- USAGE LOGS
------------------------------------------------------------

CREATE TABLE IF NOT EXISTS usage_logs (
  id              BIGSERIAL PRIMARY KEY,
  user_id         BIGINT REFERENCES users(id) ON DELETE SET NULL,
  project_id      UUID REFERENCES projects(id) ON DELETE SET NULL,
  provider_id     UUID REFERENCES ai_providers(id) ON DELETE SET NULL,
  model_id        UUID REFERENCES ai_provider_models(id) ON DELETE SET NULL,
  provider_key_id UUID REFERENCES ai_provider_keys(id) ON DELETE SET NULL,
  tokens_in       INTEGER NOT NULL DEFAULT 0,
  tokens_out      INTEGER NOT NULL DEFAULT 0,
  cost            NUMERIC(10,4),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_usage_tokens_in
    CHECK (tokens_in >= 0),
  CONSTRAINT chk_usage_tokens_out
    CHECK (tokens_out >= 0)
);

CREATE INDEX IF NOT EXISTS idx_usage_project_id ON usage_logs(project_id);
CREATE INDEX IF NOT EXISTS idx_usage_created_at ON usage_logs(created_at);


------------------------------------------------------------
-- TRIGGERS: updated_at
------------------------------------------------------------

CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated
BEFORE UPDATE ON users
FOR EACH ROW EXECUTE PROCEDURE update_timestamp();

CREATE TRIGGER trg_providers_updated
BEFORE UPDATE ON ai_providers
FOR EACH ROW EXECUTE PROCEDURE update_timestamp();

CREATE TRIGGER trg_projects_updated
BEFORE UPDATE ON projects
FOR EACH ROW EXECUTE PROCEDURE update_timestamp();


------------------------------------------------------------
-- INITIAL PROVIDER SEED (idempotent)
------------------------------------------------------------

INSERT INTO ai_providers (code, display_name, adapter_file, description)
VALUES
 ('openai',   'OpenAI',          'openai.adapter',   'OpenAI GPT Models'),
 ('gemini',   'Google Gemini',   'gemini.adapter',   'Gemini Models'),
 ('claude',   'Anthropic',       'claude.adapter',   'Claude Models'),
 ('deepseek', 'DeepSeek',        'deepseek.adapter', 'DeepSeek Models')
ON CONFLICT (code) DO NOTHING;
