#!/bin/bash

echo "============================================"
echo " AI SYSTEM HEALTH CHECK "
echo "============================================"
echo

ROOT_DIR=$(dirname "$0")/..
cd "$ROOT_DIR" || exit 1

### 1. Check required directories
echo "[1] Checking required directories..."
REQUIRED_DIRS=(
  "src"
  "src/modules"
  "src/modules/providers"
  "src/modules/projects"
  "src/modules/messages"
  "src/utils"
)

for dir in "${REQUIRED_DIRS[@]}"; do
  if [ -d "$dir" ]; then
    echo " OK: $dir"
  else
    echo " ERROR: Missing directory $dir"
  fi
done
echo

### 2. Check required files
echo "[2] Checking important files..."
REQUIRED_FILES=(
  "src/index.ts"
  "src/config.ts"
  "package.json"
  "tsconfig.json"
)

for file in "${REQUIRED_FILES[@]}"; do
  if [ -f "$file" ]; then
    echo " OK: $file"
  else
    echo " ERROR: Missing file $file"
  fi
done
echo

### 3. Verify environment variables
echo "[3] Checking environment variables..."
REQUIRED_ENV=(
  "DATABASE_URL"
  "JWT_SECRET"
  "API_KEY_ENCRYPTION_SECRET"
)

for var in "${REQUIRED_ENV[@]}"; do
  if [ -z "${!var}" ]; then
    echo " ERROR: $var is not set"
  else
    echo " OK: $var"
  fi
done
echo

### 4. API health check
echo "[4] Checking API /system/health..."
HEALTH=$(curl -s http://localhost:8000/system/health)

if echo "$HEALTH" | grep -q '"status":"ok"'; then
  echo " API OK"
else
  echo " API WARNING or ERROR:"
  echo "$HEALTH"
fi
echo

### 5. Database check
echo "[5] Checking database connectivity..."
psql "$DATABASE_URL" -c "SELECT NOW();" >/dev/null 2>&1
if [ $? -eq 0 ]; then
  echo " DB OK"
else
  echo " ERROR: Cannot connect to database"
fi
echo

echo "============================================"
echo " HEALTH CHECK COMPLETE "
echo "============================================"
