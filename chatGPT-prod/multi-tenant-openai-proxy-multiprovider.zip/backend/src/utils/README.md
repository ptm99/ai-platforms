Utilities for token estimation
